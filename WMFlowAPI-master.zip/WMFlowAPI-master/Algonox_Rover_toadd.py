import pandas as pd
import pyodbc
from datetime import datetime
import datetime
import os
import ast
import json
import xlrd
import logging
import shutil
from colorama import Fore, Back, Style 
from colorama import init
import os.path, time
from os.path import basename
from zipfile import ZipFile
import base64
import collections
init()

def get_file_path(conf_path):
    with open(conf_path, 'r') as fo:
        path_dict = fo.read()
        path_dict = ast.literal_eval(path_dict)
    return path_dict




#---------------------------------------------Sql connection-------------------------------------------------------------


# for production
# def SQL_Connect():
#     print(Fore.WHITE+'inside production SQL_Connect function')
#     database='INDTVAUTOPROD'
#     host_ = r"wmflowdbprod.database.windows.net"
#     user_ = "wmflowdbprod"
#     password_ = "WMFl0wdb@pr0d!"
#     try:
#         pointer = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + host_ +';DATABASE=' + database+';UID='+user_+';PWD='+password_+';Encrypt=yes;')
        
#     except Exception as e:
#         print("Unable to connect the Database!")

    # return pointer

# # for staging
# def SQL_Connect():
# 	#conf_file_path = 'C:\\Client\\Conf_Path.txt'
# 	conf_file_path=str(os.getcwd())+'\\Conf_Path.json'
# 	config_dic=get_file_path(conf_file_path)
# 	print(Fore.WHITE+'inside staging SQL_Connect function')
# 	# database='INDTVAUTOSTG'
# 	# host_ = r"wmflowdbstg.database.windows.net"
# 	# user_ = "flowdbstg@wmflowdbstg"
# 	# #user_='Sflowdbuser' 
# 	# password_ ="WMFl0wdb@stg!"
# 	database=config_dic["DataBaseName"]
# 	host_=config_dic["Host"]
# 	user_=config_dic["User"]
# 	password_=config_dic["Password"]
# 	driver_=config_dic["DRIVER"]
# 	#print("config_dic is---------------------------")
# 	#print(config_dic)
# 	try:
# 		pointer = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + host_ +';DATABASE=' + database+';UID='+user_+';PWD='+password_+';Encrypt=yes')
# 		return pointer
# 	except Exception as e:
# 		print("Unable to connect the Database!")
# 		print(e)
# 		return "error"



# for development
# def SQL_Connect():
# 	print(Fore.WHITE+'inside SQL_Connect function')
# 	#database='WMFlowNew'
# 	database='WMFlowNew'
# 	host_ = r"USER-PC\SQLEXPRESS"
# 	#user_ = "harnath"
# 	#password_ ="1234"
# 	user_ = "sa"
# 	password_ ="Annapurna@96"
# 	if user_ or password_:
# 		pointer = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + host_ +';DATABASE=' + database+';UID='+user_+';PWD='+password_)
# 	else:
#    		print('HERE')
#    		pointer = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + host_ + ';DATABASE=' + database)
# 	return pointer
# def SQL_Connect():
# 	conn = pyodbc.connect('Driver={SQL Server};'
# 						'Server=DFKT57S2;'
# 						'Database=WMFlow;'
# 						'Trusted_Connection=yes;')
# 	return conn


# for development

def SQL_Connect():
	# print("connecting to data base")
	conn = pyodbc.connect('Driver={SQL Server};'
						'Server=DFKT57S2;'
						'Database=WMFlow;'
						'Trusted_Connection=yes;')
	# print("connected to data base")
	return conn


pointer=SQL_Connect()
cursor=pointer.cursor()


pointer=SQL_Connect()
cursor=pointer.cursor()

#--------------------------------------------execte query---------------------------------------------------------------
def execte_query(query):
	query_dic={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute(query)  
		myresult = cursor.fetchall()
		#print(myresult)
		for i in myresult:
			query_dic[i[0]]=i[1]
	except Exception as e:
		print(Fore.RED+"error in exect query")
		print(Fore.RED+str(e))
		pointer.rollback()
		pointer.close()
	return(query_dic)

def InsertWebAppException(source,function,file_name,error):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("[dbo].[InsertWebAppException] ?,?,?,?",(source,function,str(file_name),str(error)))
		cursor.commit()
		print(Fore.YELLOW+"error is recorded")
	except Exception as e:
		print(Fore.RED+"error in InsertWebAppException")
		print(Fore.RED+e)
		pointer.rollback()
		pointer.close()

def GetPlanInfo(PlanId):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	cursor.execute("exec [dbo].[GetPlanInfo] @PlanId=?",(PlanId))
	result = cursor.fetchall()
	return result 

#-------------------------------------User logine page-------------------------------------------------------------------

def login_function(dic):
	privilegers_dic={}
	master_dic={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[GetUserNameAndRole] @EmailId=?,@Password=?",(dic['useremail'],dic['password']))
		dummy_data= cursor.fetchall()
		#print('data from data base(get user name and role ) is :',dummy_data)
		#print('data from active directiry is:',dummy_data)
		if(len(dummy_data[0])==1):
			str1=dic['currentdate'].replace(',','')
			date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')
			cursor.execute("exec [dbo].[InsertLoginAttempt] @LoggedInDateTime=?,@isLoginSuccess=?",(date_time_obj,False))
			master_dic['validlogin']=str(False).lower()
			return master_dic
		else:	
			master_dic['validlogin']=str(True).lower()
			master_dic['useremail']=dummy_data[0][0]
			master_dic['username']=dummy_data[0][1]
			master_dic['role']=dummy_data[0][2]
			#master_dic['username']=dummy_data[0][3]
			cursor.execute("exec [dbo].[UpsertUser] @UserEmailId=?,@UserName=?,@RoleName=?",(dummy_data[0][0],dummy_data[0][1],dummy_data[0][2]))
			user_id= cursor.fetchall()
			#print("data from upsert user is ",user_id)
			cursor.commit()
			#print('data from upsert(user id) is: ',user_id)
			master_dic['isnewuser']=str(user_id[0][1]).lower()
			master_dic['user_id']=user_id[0][0]
			
			cursor.execute("exec [dbo].[IsProfileCreated] @UserId=?",(master_dic['user_id']))
			isprofile_created=cursor.fetchall()
			master_dic['isprofile_created']=str(isprofile_created[0][1]).lower()

			
			
			str1=dic['currentdate'].replace(',','')
			date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')
			cursor.execute("exec [dbo].[InsertLoginAttempt] @LoggedInDateTime=?,@isLoginSuccess=?,@UserEmailId=?",(date_time_obj,True,user_id[0][0]))
			sessionid=cursor.fetchall()
			cursor.commit()
			#print('data from insertloginattempt(session id) data base  is: ',sessionid[0][0])
			master_dic['sessionid']=int(sessionid[0][0])
			
			cursor.execute("exec [dbo].[GetUserRoleAndPrivilege] @UserId=?",(user_id[0][0]))
			roleandprivileges= cursor.fetchall()
			#print('roles and roleandprivileges Are from data base ',roleandprivileges)
			privilegers=[]
			for i in range(len(roleandprivileges)):
				privilegers.append(roleandprivileges[i][1])
			#print('privilegers are ',privilegers)
			for i in privilegers:
				privilegers_dic[i]=str(True).lower()
			master_dic['privilegers']=privilegers_dic
			query="[dbo].[GetFieldDescription]"
			master_dic['tool_tips']=execte_query(query) 

	except Exception as e:
		print(Fore.RED+"error in Login function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Login function",os.path.basename(__file__),str(e))
		pointer.rollback()
		pointer.close()
	return master_dic

"""=======================================AD Login=================================="""
def login_function_ad(dic):
	print("originalllllllllllll",dic)
	privilegers_dic={}
	master_dic={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		ad_dict = json.loads(dic['responsefromad'])
		master_dic['validlogin']=str(True).lower()
		master_dic['useremail'] = ad_dict['mail']
		master_dic['username'] = ad_dict['displayName']
		# master_dic['role']=dummy_data[0][2]
		#master_dic['username']=dummy_data[0][3]
		
		cursor.execute("exec [dbo].[UpsertUser] @UserEmailId=?,@UserName=?",(master_dic["useremail"], master_dic["username"]))
		user_id= cursor.fetchall()
		print("data from upsert user is ",user_id)
		cursor.commit()
		#print('data from upsert(user id) is: ',user_id)
		master_dic['isnewuser']=str(user_id[0][1]).lower()
		master_dic['user_id']=user_id[0][0]
		master_dic['role']=str(user_id[0][2])
		
		cursor.execute("exec [dbo].[IsProfileCreated] @UserId=?",(master_dic['user_id']))
		isprofile_created=cursor.fetchall()
		master_dic['isprofile_created']=str(isprofile_created[0][1]).lower()

		print("hereee1")
		str1=dic['currentdate'].replace(',','')
		print("hereeee2")
		date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')
		cursor.execute("exec [dbo].[InsertLoginAttempt] @LoggedInDateTime=?,@isLoginSuccess=?,@UserEmailId=?",(date_time_obj,True,user_id[0][0]))
		sessionid=cursor.fetchall()
		cursor.commit()
		#print('data from insertloginattempt(session id) data base  is: ',sessionid[0][0])
		master_dic['sessionid']=int(sessionid[0][0])
		
		cursor.execute("exec [dbo].[GetUserRoleAndPrivilege] @UserId=?",(user_id[0][0]))
		roleandprivileges= cursor.fetchall()
		#print('roles and roleandprivileges Are from data base ',roleandprivileges)
		privilegers=[]
		for i in range(len(roleandprivileges)):
			privilegers.append(roleandprivileges[i][1])
		#print('privilegers are ',privilegers)
		for i in privilegers:
			privilegers_dic[i]=str(True).lower()
		master_dic['privilegers']=privilegers_dic
		query="[dbo].[GetFieldDescription]"
		master_dic['tool_tips']=execte_query(query)
	except Exception as e:
		print(Fore.RED+"error in Login function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Login function",os.path.basename(__file__),str(e))
		pointer.rollback()
		pointer.close()
	print("master_diccccccccccccc", master_dic)
	return master_dic

"""=======================================AD Login End=============================="""
def login_function_1(dic):
	privilegers_dic={}
	master_dic={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[GetUserNameAndRole] @EmailId=?,@Password=?",(dic['useremail'],dic['password']))
		dummy_data= cursor.fetchall()
		#print('data from data base(get user name and role ) is :',dummy_data)
		#print('data from active directiry is:',dummy_data)
		if(len(dummy_data[0])==1):
			str1=dic['currentdate'].replace(',','')
			date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')
			cursor.execute("exec [dbo].[InsertLoginAttempt] @LoggedInDateTime=?,@isLoginSuccess=?",(date_time_obj,False))
			master_dic['validlogin']=str(False).lower()
			return master_dic
		else:	
			master_dic['validlogin']=str(True).lower()
			master_dic['useremail']=dummy_data[0][0]
			master_dic['username']=dummy_data[0][1]
			#master_dic['role']=dummy_data[0][2]
			#master_dic['username']=dummy_data[0][3]
			cursor.execute("exec [dbo].[UpsertUser] @UserEmailId=?,@UserName=?",(dummy_data[0][0],dummy_data[0][1]))
			user_id= cursor.fetchall()
			#print("data from upsert user is ",user_id)
			cursor.commit()
			#print('data from upsert(user id) is: ',user_id)
			master_dic['isnewuser']=str(user_id[0][1]).lower()
			master_dic['user_id']=int(user_id[0][0])
			master_dic['role']=str(user_id[0][2])
			
			cursor.execute("exec [dbo].[IsProfileCreated] @UserId=?",(master_dic['user_id']))
			isprofile_created=cursor.fetchall()
			master_dic['isprofile_created']=str(isprofile_created[0][1]).lower()

			
			
			str1=dic['currentdate'].replace(',','')
			date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')
			cursor.execute("exec [dbo].[InsertLoginAttempt] @LoggedInDateTime=?,@isLoginSuccess=?,@UserEmailId=?",(date_time_obj,True,user_id[0][0]))
			sessionid=cursor.fetchall()
			cursor.commit()
			#print('data from insertloginattempt(session id) data base  is: ',sessionid[0][0])
			master_dic['sessionid']=int(sessionid[0][0])
			
			cursor.execute("exec [dbo].[GetUserRoleAndPrivilege] @UserId=?",(user_id[0][0]))
			roleandprivileges= cursor.fetchall()
			#print('roles and roleandprivileges Are from data base ',roleandprivileges)
			privilegers=[]
			for i in range(len(roleandprivileges)):
				privilegers.append(roleandprivileges[i][1])
			#print('privilegers are ',privilegers)
			for i in privilegers:
				privilegers_dic[i]=str(True).lower()
			master_dic['privilegers']=privilegers_dic
			query="[dbo].[GetFieldDescription]"
			master_dic['tool_tips']=execte_query(query) 

	except Exception as e:
		print(Fore.RED+"error in Login function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Login function",os.path.basename(__file__),str(e))
		pointer.rollback()
		pointer.close()
	return master_dic


#------------------------------------------logout page---------------------------------------------------------------------

def logout_function(dic):
	#print('',dic)
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		str1=dic['loggedoutdatetime'].replace(',','')
		#print('converted date only  is ',str1)
		#date_time_obj = datetime.datetime.strptime(str1, '%m/%d/%Y %I:%M:%S %p')
		date_time_obj=datetime.datetime.strptime(str1,'%m/%d/%Y %I:%M:%S %p').strftime('%Y/%m/%d %I:%M:%S %p')	
		cursor.execute("exec [dbo].[UpdateLogoutAttempt] @SessionId=?,@LoggedOutDateTime=?,@isSessionTimedOut=?",(dic['sessionid'],date_time_obj,dic['issessiontimedout']))
		cursor.commit()
		return ("logout done")
	except Exception as e:
		print(Fore.RED+"error in Logout function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Logout function",os.path.basename(__file__),str(e))
		pointer.rollback()
		pointer.close()
		return ("logout failed")

#-------------------------------------------planner profile page-------------------------------------------------------------
	
def Location_function():
	try:
		location_dic={}
		query="exec [dbo].[GetLocations]"
		location_dic=execte_query(query)
		return location_dic
	except Exception as e:
		print(Fore.RED+"error in Location function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Location function",os.path.basename(__file__),str(e))	
		location_dic={'message':"fail"}
		return location_dic
def Client_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	client_dic={}
	try:
		for i in dic['location_name']:
			cursor.execute("exec [dbo].[GetClientsByLocation] ?",str(i))
			myresult= cursor.fetchall()
			for j in myresult:
				client_dic[j[0]]=j[1]
		return client_dic
	except Exception as e:
		print(Fore.RED+"error in Client function")
		print(Fore.RED+str(e))
		cursor.rollback()
		cursor.close()
		InsertWebAppException("Python","Client function",os.path.basename(__file__),str(e))
		client_dic={'message':"fail"}
		return client_dic

def Client_Lead_function(dic):   # need to talk about error message 
	leads={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		for i in dic['clientNames']:
			temp_list=[]
			cursor.execute("exec [dbo].[GetClientLeadForClient] ?",str(i))
			myresult = cursor.fetchall()
			#print(myresult)
			for j in myresult:
				temp_list.append(j[1])
			leads[i]=temp_list
		#print(leads)
		keys=list(leads.keys())
		valus=list(leads.values())
		clientleads_list=[]
		for i in range(len (keys)):
			s=str(str(dic['clientNames'][i])+':'+str(",".join(valus[i])))
			#print(s)
			clientleads_list.append(s)
		return(clientleads_list)
	except Exception as e:
		print(Fore.RED+"error in Client lead function")
		print(str(e))
		cursor.rollback()
		cursor.close()
		InsertWebAppException("Python","Client lead function",os.path.basename(__file__),str(e))
		return {'message':"fail"}
def Create_Profile_function(dic): # need to talk about this 
	#inserted_recordedids=[]
	inserted_recordedids={}
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("[dbo].[UpdateUser] @UserId=?,@LocationName=?",(int(dic['UserClientId']),dic['location_key'][0]))
		cursor.commit()
		print('before delete client user delete')
		cursor.execute("[dbo].[DeleteClientForUser] @UserId=?",(int(dic['UserClientId'])))
		cursor.commit()
		print('after delete client user delete')
		for l in dic['ClientId']:
			print(l)
			cursor.execute('''[dbo].[UpsertUserClient] @ClientName=?,@UserId=?''',(str(l),int(dic['UserClientId'])))
			myresult = cursor.fetchall()
			#print(myresult)
			cursor.commit()
			#inserted_recordedids.append((int(myresult[0][0])))
			#print(myresult[0][0])
			inserted_recordedids['ProfileId']=int(myresult[0][0])
		return inserted_recordedids
	except Exception as e:
		print(Fore.RED+"error in create profile function")
		print(Fore.RED+str(e))
		cursor.rollback()
		cursor.close()
		InsertWebAppException("Python","Create profile function",os.path.basename(__file__),str(e))
		inserted_recordedids={'message':"fail"}
		return inserted_recordedids

def Create_Profile_freeze_function(dic):
	return_dic={}
	client_result=[]
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute('''[dbo].[GetUserProfile] @UserId=?''',(int(dic["user_id"])))
		myresult = cursor.fetchall()
		for i in myresult:
			client_result.append(i[1])
		return_dic['Email_ID']=myresult[0][2]
		return_dic['Client']=client_result
		return_dic['Location']=myresult[0][0]
		#return_dic['Client_Lead']=Client_Lead_function(return_dic['Client'])	
		cursor.execute('''[dbo].[GetClientLeadForPlanner] @UserId=?''',(int(dic["user_id"]))) 
		myresult = cursor.fetchall()
		temp_dic={}
		for i in client_result:
			temp_list=[]
			for j in myresult:
				if(j[1]==i):
					temp_list.append(j[0])
			temp_dic[i]=temp_list
		#print(temp_dic)
		keys=list(temp_dic.keys())
		valus=list(temp_dic.values())
		#print(keys,valus)
		clientleads_list=[]

		for i in range(len (keys)):
			s=str(str(keys[i])+':'+str(",".join(valus[i])))
			clientleads_list.append(s)
		return_dic['Client_Lead']=clientleads_list
		return(return_dic)
	except Exception as e :
		print(Fore.RED+"error in create profile freeze function")
		print(Fore.RED+str(e))
		cursor.rollback()
		cursor.close()
		InsertWebAppException("Python","Create profile freeze function",os.path.basename(__file__),str(e))
		return_dic={'message':"fail"}
		return return_dic

#--------------------------create plane----------------------------------------------------------------------------------

def Base_Tg():
	Base_Tg={}
	query="exec [dbo].[GetBaseTG]"  
	Base_Tg=execte_query(query)
	return(Base_Tg)

def Primary_Tg():
	Primary_Tg={}
	query="exec [dbo].[GetPrimaryTG]"
	Primary_Tg=execte_query(query)
	return(Primary_Tg)

def Campaign_Market():
	Campaign_Market={}
	query="exec [dbo].[GetCampaignMarket]"
	Campaign_Market=execte_query(query)
	return (Campaign_Market)

def End_Week():
	End_Week={}
	query="exec [dbo].[GetEndWeek]"
	End_Week=execte_query(query)
	return End_Week

def GetClientAndBrandForUser(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		brand_client={}
		client=[]
		cursor.execute("exec [dbo].[GetClientAndBrandForUser] ?",(int(dic['user_id']))) 
		myresult = cursor.fetchall()
		#print(myresult)
		for i in myresult:
			client.append(i[3])
		client=list(set(client))
		for i in client:
			brand_temp=[]
			for j in myresult:
				if(i==j[3]):
					brand_temp.append(j[1])
			brand_client[i]=brand_temp
		return brand_client
	except Exception as e:
		print(Fore.RED+"error in GetClientAndBrandForUser")
		print(Fore.RED+str(e))
		cursor.rollback()
		cursor.close()
		InsertWebAppException("Python","Get client and brand for user",os.path.basename(__file__),str(e))
		brand_client={'message':"fail"}
		return None

def Create_plane_Function(dic):
	try:
		master_dic={}
		# if GetClientAndBrandForUser(dic):
		# 	#raise ValueError('A very specific bad thing happened.')
		# 	raise Exception('general exceptions not caught by specific handling')
		# 	#master_dic['Client']=GetClientAndBrandForUser(dic)
		master_dic['Client']=GetClientAndBrandForUser(dic)
		master_dic['Base_Tg']=Base_Tg()
		master_dic['Primary_Tg']=Primary_Tg()
		#master_dic['Campaign_Market']=Campaign_Market()
		#-----------------new block of code for campaign market---------------------------
		Campaign_Market_not_sorted=Campaign_Market()
		sorted_x = sorted(Campaign_Market_not_sorted.items(), key=lambda kv: kv[1])
		sorted_dict = collections.OrderedDict(sorted_x)
		master_dic['Campaign_Market']=dict(sorted_dict)
		#-------------------end-------------------------------------------------------------
		master_dic['End_Week']=End_Week()
		return master_dic

	except Exception as e:
		print(Fore.RED+"error in create plan function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Create plan function",os.path.basename(__file__),str(e))
		master_dic={'message':"fail"}
		return master_dic

def Create_plan_Button_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	plan_dic={}
	try:
		cursor.execute("exec [dbo].[InsertPlan] @ClientName=?,@BrandName=?,@CampaignName=?,@CampaignId=?,@PrimaryTGId=?,@BaseTGId=?,@UserId=?,@EndWeekId=?",(dic['ClientId'][0],dic['BrandId'][0],dic['CampaignName'],dic['CampaignId'],dic['PrimaryTGTd'],dic['BaseTGId'],dic['user_id'],dic['EndWeekId']))
		print('inserd plan done')
		myresult = cursor.fetchall()
		marketids=int(myresult[0][0])
		cursor.commit()
		for i in dic['CampaignMarketId']:
			print(Fore.WHITE+'campaign market sent for insert is ',i)
			cursor.execute("exec [dbo].[UpsertCampaignMarketForPlan] @UserId=?,@PlanId=?,@CampaignMarketName=?",dic['user_id'],marketids,str(i))
			myresult = cursor.fetchall()
			CampaignMarketId=int(myresult[0][0])
			cursor.commit()
			print(Fore.WHITE+'market inserted generated ids are :',CampaignMarketId)
			plan_dic['createplanid']=str(marketids)
		return(plan_dic)
	except Exception as e :
		print(Fore.RED+"error in create plan button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Create plan button function",os.path.basename(__file__),str(e))
		return({'message':"fail"})

def Create_plan_freeze_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		return_dic={}
		cursor.execute("exec [dbo].[GetPlan] @PlanId=?",(dic['createplanid']))
		myresult = cursor.fetchall()
		print(myresult)
		return_dic['Brand']=myresult[0][0]
		return_dic['Client']=myresult[0][1]
		return_dic['CampaignName']=myresult[0][2]
		return_dic['CampaignId']=myresult[0][3]
		return_dic['PrimaryTGTd']=myresult[0][4]
		return_dic['BaseTGId']=myresult[0][5]
		return_dic['EndWeek']=myresult[0][7]
		return_dic['ischannelselectioncompleted']=str(myresult[0][8]).lower()
		return_dic['buyingbasketfilepath']=myresult[0][9]
		return_dic['planProcessed']=myresult[0][10]
		return_dic['IsMarkAsCompleted']=str(myresult[0][11]).lower()
		return_dic['AcceleratedFilePath']=myresult[0][12]
		temp_list=[]
		for i in myresult:
			temp_list.append(i[6])
		return_dic['CampaignMarketId']=temp_list
		return(return_dic)
	except Exception as e: 
		print(Fore.RED+"error in create plan freeze function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Create plan freeze function",os.path.basename(__file__),str(e))
	#print('Create_plan_freeze_function final out for ui is:',return_dic)
		return_dic={'message':"fail"}
		return(return_dic)

#-----------------------------------------------------dash board blocks -------------------------------------------------------

def Dashboard(dic,query):    # need to talk with ui people for error handling 
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	results=[]
	try:
		
		if(len(dic)==2):
			cursor.execute("exec "+query+" @Userid=?,@IsDefault=?",(int(dic['user_id']),True))
		else:
			cursor.execute("exec "+query+" @Userid=?,@StartDate=?,@Enddate=?,@IsDefault=?",(int(dic['user_id']),dic['startdate'],dic['enddate'],False))
		columns = [column[0] for column in cursor.description]
		for row in cursor.fetchall():
			results.append(dict(zip(columns, row)))
		print("resultssssssssss", results)
		return(results)
	except Exception as e: 
		print(Fore.RED+"error in Dashboard")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Dashboard",os.path.basename(__file__),str(e))	
		return({'message':"fail"})

def gobutton_function(dic,query): # need to talk with ui people for error handling
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	results = []
	try:
		if(dic['IsDefault']==True):
			print(Fore.WHITE+"top 10 records")
			cursor.execute("exec "+query+" @IsDefault=?,@UserId=?",(True,int(dic['user_id'])))
		elif(dic['Campaignid']):
			print(Fore.WHITE+'only on campaignId')
			cursor.execute("exec "+query+" @CampaignId=?,@IsDefault=?,@UserId=?",(str(dic['Campaignid']),False,int(dic['user_id'])))
		elif(dic['startdate'] and dic['enddate']):
			
			start_object= datetime.datetime.strptime(dic['startdate'],'%Y-%m-%d').date()
			end_object= datetime.datetime.strptime(dic['enddate'],'%Y-%m-%d').date()
			if(dic['brandclass']):
				print(Fore.WHITE+'start,end,brand')
				cursor.execute("exec "+query+" @BrandName=?,@Startdate=?,@Enddate=?,@IsDefault=?,@UserId=?",(dic['brandclass'],start_object,end_object,False,int(dic['user_id'])))
			elif(dic['clientclass']):
				print(Fore.WHITE+'start,end,client')
				cursor.execute("exec "+query+" @ClientName=?,@Startdate=?,@Enddate=?,@IsDefault=?,@UserId=?",(dic['clientclass'],start_object,end_object,False,int(dic['user_id'])))
			else:
				print(Fore.WHITE+'only on start and end date')
				cursor.execute("exec "+query+" @Startdate=?,@Enddate=?,@IsDefault=?,@UserId=?",(start_object,end_object,False,int(dic['user_id'])))
		elif(dic['brandclass']):
			print(Fore.WHITE+'only brand')
			cursor.execute("exec "+query+" @BrandName=?,@IsDefault=?,@UserId=?",(dic['brandclass'],False,int(dic['user_id'])))
		elif(dic['clientclass']):
			print(Fore.WHITE+'only client')
			cursor.execute("exec "+query+" @ClientName=?,@IsDefault=?,@UserId=?",(dic['clientclass'],False,int(dic['user_id'])))
		else:
			cursor.execute("exec "+query+" @IsDefault=?,@UserId=?",(True,int(dic['user_id'])))
		columns = [column[0] for column in cursor.description]
		print(Fore.WHITE+"columns are :",columns)
		
		for row in cursor.fetchall():
			results.append(dict(zip(columns, row)))
		return results
	except Exception as e:
		print(Fore.RED+"error in Go button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Go button function",os.path.basename(__file__),str(e))
		return results

def Dashboard_Table_flag(dic):
	Dashboard_dic={}
	try:
		query="[dbo].[GetOngoingPlanForPlanner]"
		results=Dashboard(dic,query)
		for i in range(len(results)):
			results[i]['StartDate']=str(results[i]['StartDate'])
		Dashboard_dic['Incompleted']=results
		
		query="[dbo].[GetCompletedPlansForPlanner]"
		results=Dashboard(dic,query)
		for i in range(len(results)):
			results[i]['StartDate']=str(results[i]['StartDate'])
			results[i]['EndDate']=str(results[i]['EndDate'])
		Dashboard_dic['Completed']=results
		return Dashboard_dic

	except Exception as e:
		print(Fore.RED+"error in Dashboard Table flag")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Dashboard Table flag",os.path.basename(__file__),str(e))
		Dashboard_dic={'message':"fail"}
		return Dashboard_dic

def Dashboard_Table_dates(dic):
	Dashboard_dic={}
	try:
		query="[dbo].[GetOngoingPlanForPlanner]"
		results=Dashboard(dic,query)
		print("Dashboard_Table_datesssssssssss_ongoing", results)

		for i in range(len(results)):
			results[i]['StartDate']=str(results[i]['StartDate'])
		Dashboard_dic['Incompleted']=results
		
		query="[dbo].[GetCompletedPlansForPlanner]"
		results=Dashboard(dic,query)
		print("Dashboard_Table_datesssssssssss_copleted", results)
		for i in range(len(results)):
			results[i]['StartDate']=str(results[i]['StartDate'])
			results[i]['EndDate']=str(results[i]['EndDate'])
		Dashboard_dic['Completed']=results
		#Dashboard_dic={'message':"fail"}
		return Dashboard_dic

	except Exception as e:
		print(Fore.RED+"error in Dashboard table dates")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Dashboard table dates",os.path.basename(__file__),str(e))
		Dashboard_dic={'message':"fail"}
		return Dashboard_dic

def Complete_Button_Function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[UpdatePlanAsComplete] @PlanId=?,@UserId=?",(dic['Id'],dic['user_id']))
		cursor.commit()
		return ("Updated")
	except Exception as e:
		print(Fore.RED+"error in Complete button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Complete button function",os.path.basename(__file__),str(e))
		return ("Not Updated")

#--------------------------------------ongoingpage-------------------------------------------------

def ongoing_screenload_function(dic):
	try:
		query="[dbo].[GetOngoingPlansByFilter]"
		filter_data=gobutton_function(dic,query)
		for i in range(len(filter_data)):
			filter_data[i]['StartDate']=str(filter_data[i]['StartDate'])
		return filter_data
	except Exception as e:
		print(Fore.RED+"error in ongoing screenload function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","ongoing screenload function",os.path.basename(__file__),str(e))
		filter_data={'message':"fail"}
		return (filter_data)

def ongoing_gobutton_function(dic):
	try:
		dic['IsDefault']=False
		query="[dbo].[GetOngoingPlansByFilter]"
		filter_data=gobutton_function(dic,query)
		for i in range(len(filter_data)):
			filter_data[i]['StartDate']=str(filter_data[i]['StartDate'])
	except Exception as e:
		print(Fore.RED+"error in ongoing gobutton function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","ongoing gobutton function",os.path.basename(__file__),str(e))
		filter_data={'message':"fail"}
	return (filter_data)

def ongoing_prioritize_button_function(dic):
	#results=[]
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[UpdatePlannerPrioritize] @PlanId=?,@UserId=?",(int(dic['plainid']),int(dic['user_id'])))
		cursor.commit()
		result=ongoing_gobutton_function(dic)
		#print('dic---------------------',dic)
	except Exception as e:
		print(Fore.RED+"error in ongoing prioritize button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","ongoing prioritize button function",os.path.basename(__file__),str(e))	
	return(result)
	
	#--------------------------completed page---------------------------------------------------------

def comleted_screenload_function(dic):
    query="[dbo].[GetCompletedPlansByFilter]"
    filter_data=gobutton_function(dic,query)
    for i in range(len(filter_data)):
        filter_data[i]['StartDate']=str(filter_data[i]['StartDate'])
        filter_data[i]['EndDate']=str(filter_data[i]['EndDate'])
    return (filter_data)

def comleted_gobutton_function(dic):
	query="[dbo].[GetCompletedPlansByFilter]"
	dic['IsDefault']=False
	filter_data=gobutton_function(dic,query)
	for i in range(len(filter_data)):
		filter_data[i]['StartDate']=str(filter_data[i]['StartDate'])
		filter_data[i]['EndDate']=str(filter_data[i]['EndDate'])
	return (filter_data)

def replan_campaign(dic):
	pointer=SQL_Connect()
	cursor=pointer.cursor()
	replan_dic={}
	try:
		campaign_id = (dic['CampaignId'])
		user_id = int(dic['user_id'])
		cursor.execute("exec [dbo].[RePlanCampaign] @CampaignId=?,@UserId=?,@RePlanCategory=?",(campaign_id,int(user_id),int(dic['RePlanCategory'])))
		myresult = cursor.fetchall()
		cursor.commit()
		replan_dic['planid']=myresult[0][0]
		
		return(replan_dic)	

	except Exception as e:
		print(Fore.RED+"error in replan campaign")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","replan campaign ",os.path.basename(__file__),str(e))	
		replan_dic={'message':"fail"}
		return(replan_dic)	

#---------------------------Barc evalution -----------------------------------------------------------------

#need to ask ther are usig index are key value pairs:
def Barc_freeze_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	return_dic={}
	try:
		cursor.execute("exec [dbo].[GetPlan] @PlanId=?",(dic['planId']))
		myresult = cursor.fetchall()
		return_dic['Brand']=myresult[0][0]
		return_dic['Client']=myresult[0][1]
		return_dic['CampaignName']=myresult[0][2]
		return_dic['CampaignId']=myresult[0][3]
		return_dic['PrimaryTGTd']=myresult[0][4]
		return_dic['BaseTGId']=myresult[0][5]
		return_dic['EndWeek']=myresult[0][7]
		temp_list=[]
		for i in range(len(myresult)):
			temp_list.append(myresult[i][6])
		return_dic['CampaignMarketId']=temp_list
		return_dic['AcceleratedFilePath']=myresult[0][12]
		return (return_dic)
	except Exception as e: 
		print(Fore.RED+"error in Barc freeze function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Barc freeze function",os.path.basename(__file__),str(e))	
		print(Fore.RED+'data has not recived from databse may be mapping problem')
		return ({'message':"fail"})

def BARC_just_confirm_button_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[ConfirmBarcevaluation] @UserId=?,@PlanId=?",(dic['user_id'],dic['PlanId']))
		cursor.commit()
		return ("updated")
	except Exception as e: 
		print(Fore.RED+"error in Barc just conform button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Barc just conform button function",os.path.basename(__file__),str(e))	
		return ("not updated")
	return ("Done!!")


def BARC_update_confirm_button_function(dic):
	#print(" in side BARC_update_confirm_button_function")
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[DeleteCampaignMarketForPlans] @PlanId=?",(dic['PlanId']))
		print("old are deleted ")
		cursor.commit()
		print('market names before for loop are :',dic['CampaignMarketId'])
		for i in dic['CampaignMarketId']:
			cursor.execute("exec [dbo].[InsertCampaignMarketForPlan] @PlanId=?,@CampaignMarketName=?,@UserId=?",(dic['PlanId']),i,dic['user_id'])
			myresult = cursor.fetchall()
			#print(myresult)
			marketids=int(myresult[0][0])
			cursor.commit()
			print(" new marketids are :",marketids)
		cursor.execute("exec [dbo].[UpdatePlanForBarcEvaluation] @UserId=?,@PlanId=?,@PrimaryTGId=?,@BaseTGId=?,@EndWeek=?",(dic['user_id'],dic['PlanId'],dic['PrimaryTGTd'],dic['BaseTGId'],dic['EndWeekId']))
		cursor.commit()
		return ("updated")
	except Exception as e: 
		print(Fore.RED+"error in Barc just conform button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Barc just conform button function",os.path.basename(__file__),str(e))	
		return ("not updated")

#------------------------------add delete function--------------------------------------------------------------------

def useremail_function():   #need to talk with ui people with errror message
	emails=[]
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[GetUserEmails]")
		myresult = cursor.fetchall()
		#print(myresult)
		for i in myresult:
			emails.append(i[0])
	except Exception as e: 
		print(Fore.RED+"error in Barc just conform button function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","Barc just conform button function",os.path.basename(__file__),str(e))	
	return emails

def planner_client_function(dic):
	print("planner_client_function",dic)
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	clients={}
	try:
		cursor.execute("exec [dbo].[GetClientAndBrandForUser] @UserId=?",(dic['user_id']))
		myresult = cursor.fetchall()
		for i in myresult:
			clients[i[2]]=i[3]
		return (clients)
	except Exception as e: 
		print(Fore.RED+"error in planner client function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","planner client function",os.path.basename(__file__),str(e))
		clients={'message':"fail"}
		return (clients)

def save_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	dt={}
	try:
		cursor.execute("exec [dbo].[UpsertUserClient] @UserId=?,@ClientId =?,@UserEmailId=?",(int(dic['user_id']),int(dic['clientid']),dic['email']))
		#primary tg 
		myresult = cursor.fetchall()
		#print(myresult)
		cursor.commit()
		for i in range(len(myresult)):
			dt[myresult[i][0]]=myresult[i][1]
		return(dt)
	except Exception as e: 
		print(Fore.RED+"error in save function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","save function",os.path.basename(__file__),str(e))
		dt={"message":"fail"}
		return(dt)

def useremail_del_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	client_email={}
		
	try:
		cursor.execute("exec [dbo].[GetUserEmails] ?",(dic))
		myresult = cursor.fetchall()
		clients_set=[]
		for i in myresult:
			clients_set.append(i[2])
		clients_set=list(set(clients_set))
		#print(clients_set)
		for i in clients_set:
			temp=[]
			for j in myresult:
				if(i==j[2]):
					temp.append(j[1])
			client_email[i]=temp
		return (client_email)

	except Exception as e: 
		print(Fore.RED+"error in user delete function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","user delete function",os.path.basename(__file__),str(e))
		client_email={"message":"fail"}
		return (client_email)

def add_save_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[UpsertUserClient] @UserId=?,@ClientId =?,@UserEmailId=?",(int(dic['user_id']),int(dic['clientid']),dic['email']))
		cursor.commit()
		return("updated")
	except Exception as e: 
		print(Fore.RED+"error in add save function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","add save function",os.path.basename(__file__),str(e))
		return ("not updated") 

def delete_save_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[UpsertUserClient] @UserId=?,@ClientName =?,@UserEmailId=?",(int(dic['user_id']),dic['clientid'],dic['email']))
		myresult = cursor.fetchall()
		CampaignMarketId=int(myresult[0][0])
		cursor.commit()
		print('generated ids are(delete save function) :',CampaignMarketId)
		return "updated"
	except Exception as e:
		print(Fore.RED+"error in delete save function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","delete save function",os.path.basename(__file__),str(e))
		return ("not updated") 

#------------------------------------buying basket----------------------------------------------------------------------------------
def version_function(dic):
	pointer=SQL_Connect()
	cursor=pointer.cursor()
	version_dic={}
	try:
		cursor.execute("exec [dbo].[GetPlanCampaignInfo] @PlanId=?",(int(dic['planid'])))
		myresult = cursor.fetchall()
		version_dic['CampaignId']=myresult[0][0]
		version_dic['Version']=myresult[0][1]
		version_dic['CampaignName']=myresult[0][2]
		version_dic['PathSelection']=myresult[0][3]
		return (version_dic)	

	except Exception as e:
		print(Fore.RED+"error in version function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","version function",os.path.basename(__file__),str(e))
		version_dic={"message":"fail"}
		return (version_dic)

def plan_selection_function_1(data):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		if 'weightage' not in data.keys():
			print("No cprp weightage and reach Weightage")
			cprp_weightage = None
			reach_weightage = None			
			print("none")
			cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CampaignDuration=?,@PlanId=?,@UserId=?",(int(data['path_selection']),int(data['campaign_days']),int(data['plan_id']),int(data['user_id'])))
			cursor.commit()
			print('acd delete has started ')
			cursor.execute("exec [dbo].[DeleteAcdDispersionForPlan] @PlanId=?",(int(data['plan_id'])))
			cursor.commit()
			print("acd delete completed")
			for i in data['acd_dispersion']:
				print("acd added")
				cursor.execute("exec [dbo].[InsertAcdDispersionForPlan] @PlanId=?,@Acd=?,@Dispersion=?",(int(data['plan_id']),int(list(i)[0]),int(i[list(i)[0]])))
				cursor.commit()
			print("this is in rover success")
			return("success")	
		else:
			print("Yes cprp weightage and reach Weightage")
			weightage = data['weightage']
			cprp_weightage=int(list(weightage.keys())[0])
			reach_weightage =int(weightage[str(cprp_weightage)])
			if(data['cprp_channel'] and data["frequency_channel"]):
				print("both")
				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@CPRPChannel=?,@FrequencyChannels=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data['cprp_channel']),int(data["frequency_channel"])))
				cursor.commit()		
			elif(data['cprp_channel']):
				print("cprp_channel")
				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@CPRPChannel=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data['cprp_channel'])))
				cursor.commit()	
			elif(data["frequency_channel"]):
				print("frequency_channel")
				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@FrequencyChannels=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data["frequency_channel"])))
				cursor.commit()
			else:
				print("none both 0")
				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id'])))
				cursor.commit()
			print('acd delete started ')
			cursor.execute("exec [dbo].[DeleteAcdDispersionForPlan] @PlanId=?",(int(data['plan_id'])))
			cursor.commit()
			print('acd delete ended')
			for i in data['acd_dispersion']:
				print("acd added")
				cursor.execute("exec [dbo].[InsertAcdDispersionForPlan] @PlanId=?,@Acd=?,@Dispersion=?",(int(data['plan_id']),int(list(i)[0]),int(i[list(i)[0]])))
				cursor.commit()
			print("this is in rover success")
			return("success")
	except Exception as e:
		print(Fore.RED+"error in plan selection function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","plan selection function",os.path.basename(__file__),str(e))
		print("Fail")
		return("Fail")

# def plan_selection_function_1(data):
# 	#pointer=SQL_Connect()
# 	#cursor=pointer.cursor()
# 	try:
# 		if 'weightage' not in data.keys():
# 			print("No cprp weightage and reach Weightage")
# 			cprp_weightage = None
# 			reach_weightage = None			
# 			print("none")
# 			cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CampaignDuration=?,@PlanId=?,@UserId=?",(int(data['path_selection']),int(data['campaign_days']),int(data['plan_id']),int(data['user_id'])))
# 			cursor.commit()
# 			print('acd delete has started ')
# 			cursor.execute("exec [dbo].[DeleteAcdDispersionForPlan] @PlanId=?",(int(data['plan_id'])))
# 			cursor.commit()
# 			print("acd delete completed")
# 			for i in data['acd_dispersion']:
# 				cursor.execute("exec [dbo].[InsertAcdDispersionForPlan] @PlanId=?,@Acd=?,@Dispersion=?",(int(data['plan_id']),int(i),int(data['acd_dispersion'][i])))
# 				cursor.commit()
# 			print("sucess")
# 			return('sucess')	
# 		else:
# 			print("Yes cprp weightage and reach Weightage")
# 			weightage = data['weightage']
# 			cprp_weightage=int(list(weightage.keys())[0])
# 			reach_weightage =int(weightage[str(cprp_weightage)])
# 			if(data['cprp_channel'] and data["frequency_channel"]):
# 				print("both")
# 				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@CPRPChannel=?,@FrequencyChannels=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data['cprp_channel']),int(data["frequency_channel"])))
# 				cursor.commit()		
# 			elif(data['cprp_channel']):
# 				print("cprp_channel")
# 				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@CPRPChannel=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data['cprp_channel'])))
# 				cursor.commit()	
# 			elif(data["frequency_channel"]):
# 				print("frequency_channel")
# 				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?,@FrequencyChannels=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id']),int(data["frequency_channel"])))
# 				cursor.commit()
# 			else:
# 				print("none both 0")
# 				cursor.execute("exec [dbo].[UpdatePlanForPathSelection] @FilePath=?,@CPRPWeightage=?,@ReachWeightage=?,@CampaignDuration=?,@PlanId=?,@UserId=?",(int(data['path_selection']),int(cprp_weightage),int(reach_weightage),int(data['campaign_days']),int(data['plan_id']),int(data['user_id'])))
# 				cursor.commit()
# 			print('acd delete started ')
# 			cursor.execute("exec [dbo].[DeleteAcdDispersionForPlan] @PlanId=?",(int(data['plan_id'])))
# 			cursor.commit()
# 			print('acd delete ended')
# 			for i in data['acd_dispersion']:
# 				print(i)
# 				acd_key=int((list(i.keys()))[0])
# 				print(acd_key)
# 				acd_dis=int(i[str(acd_key)])
# 				print(acd_dis)
# 				cursor.execute("exec [dbo].[InsertAcdDispersionForPlan] @PlanId=?,@Acd=?,@Dispersion=?",int(data['plan_id']),int(acd_key),int(acd_dis))
# 				print("acd added")
# 				cursor.commit()
# 			print("this is in rover success")
# 			return("success")
# 	except Exception as e:
# 		print(Fore.RED+"error in plan selection function")
# 		print(Fore.RED+str(e))
# 		#InsertWebAppException("Python","plan selection function",os.path.basename(__file__),str(e))
# 		print("Fail")
# 		return("Fail")


def buying_basket_freeze_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	masterdic={}
	acd_dispersion={}
	acd_dispersion_list=[]
	try:
		cursor.execute("exec [dbo].[GetBuyingBasketInfo] @PlanId=?",(int(dic['planid'])))
		myresult = cursor.fetchall()
		print("from data base ;---------------------------------")
		print(myresult)
		if(len(myresult[0])==5):
			masterdic['data']=False
			masterdic['CampaignId']=myresult[0][1]
			masterdic['BuyingBasketFilePath']=myresult[0][3]
			if(masterdic['BuyingBasketFilePath'] != None):
				masterdic['BuyingBasketFilePath']=myresult[0][3].split(':')[1].split('\\')[-1]
			masterdic['CampaignName']=myresult[0][4]	
		else:
			masterdic['data']=str(myresult[0][12]).lower()
			masterdic['CampaignId']=myresult[0][0]
			if (myresult[0][1] !=None):
				masterdic['BuyingBasketFilePath']=myresult[0][1].split(':')[1].split('\\')[-1]
			masterdic['PathSelection']=myresult[0][2]
			masterdic['CPRPWeightage']={myresult[0][3]:myresult[0][4]}
			#masterdic['ReachWeightage']=myresult[0][4]
			masterdic['CampaignDuration']=myresult[0][5]
			#print(myresult[0][6])
			if(myresult[0][6] !=None):
				masterdic['SpillOverSheetFilePath']=myresult[0][6].split(':')[1].split('\\')[-1]
			if myresult[0][7]:
				masterdic['BudgetAllocationFilePath']=myresult[0][7].split(':')[1].split('\\')[-1]
			else:
				masterdic['BudgetAllocationFilePath']=None
			for i in myresult:
				acd_dispersion={}
				acd_dispersion[i[8]]=i[9]
				acd_dispersion_list.append(acd_dispersion)
			masterdic['acd_dispersion']=acd_dispersion_list
			masterdic['planProcessed']=myresult[0][10]
			masterdic['isFilePrepCompleted']=str(myresult[0][11]).lower()
			masterdic['IsMarkAsComplete']=str(myresult[0][13]).lower()
			masterdic['Version']=myresult[0][14]
			masterdic['cprp_channel']=myresult[0][15]
			masterdic['frequency_channel']=myresult[0][16]
			masterdic['AcceleratedFilePathByRPA']=myresult[0][17]
			masterdic['SpillOverSheetFilePathByRPA']=myresult[0][18]
			masterdic['CampaignName']=myresult[0][19]
			if myresult[0][20]:
				masterdic['AcceleratedFilePath']=myresult[0][20]
			else:
				masterdic['AcceleratedFilePath']=None
		return (masterdic)
	except Exception as e:
		print(Fore.RED+"error in buying basket freeze function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","buying basket freeze function",os.path.basename(__file__),str(e))
		masterdic={"message":"fail"}
		return (masterdic)

def master_roles_and_Privileges_function():
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		cursor.execute("exec [dbo].[GetPrivilegesByRole]")
		myresult = cursor.fetchall()
		master_dic={}
		planner=[]
		clientlead=[]
		admin=[]
		for i in myresult:
			if(i[4]==1): #admin
				temp_planner={}
				temp_planner['Privilege_Name']=i[0]
				temp_planner['Privilage_Id']=i[1]
				temp_planner['Privilage_Value']=i[2]
				temp_planner['Privilage_Description']=i[3]
				admin.append(temp_planner)

			elif(i[4]==2):#clientlead
				temp_planner={}
				temp_planner['Privilege_Name']=i[0]
				temp_planner['Privilage_Id']=i[1]
				temp_planner['Privilage_Value']=i[2]
				temp_planner['Privilage_Description']=i[3]
				clientlead.append(temp_planner)
			elif(i[4]==4):  #planner
				temp_planner={}
				temp_planner['Privilege_Name']=i[0]
				temp_planner['Privilage_Id']=i[1]
				temp_planner['Privilage_Value']=i[2]
				temp_planner['Privilage_Description']=i[3]
				planner.append(temp_planner)
		master_dic["planner"]=planner
		master_dic["clientlead"]=clientlead
		master_dic["admin"]=admin
		return master_dic

	except Exception as e:
		print(Fore.RED+"error in master roles and Privileges function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","master roles and Privileges function",os.path.basename(__file__),str(e))
		master_dic={"message":"fail"}
		return master_dic

def master_role_update_function(dic):
	#pointer=SQL_Connect()
	#cursor=pointer.cursor()
	try:
		for i in dic['data']:
			for j in dic['data'][i]:
				if(j['Privilage_Value']=='Yes'):
					cursor.execute("[dbo].[UpsertRolePrivileges] @RoleName=?,@PrivilegeId=?,@UserId=?",(i,int(j['Privilage_Id']),int(dic['user_id'])))
					cursor.commit()
				elif(j['Privilage_Value']=='No'):
					cursor.execute("[dbo].[ArchiveRolePrivilege] @RoleName=?,@PrivilegeId=?,@UserId=?",(i,int(j['Privilage_Id']),int(dic['user_id'])))
					cursor.commit()
		print("all are updated ")
	except Exception as e:
		print(Fore.RED+"error in master roles update function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","master roles update function",os.path.basename(__file__),str(e))
		print("all are updated ")



"""========================================================== Santosh ====================================================================="""

def create_directory(folder_path):
	"""
	Helper function for directory creation
	"""
	if not os.path.exists(folder_path):  
		try:
			os.makedirs(folder_path)
		except Exception as e:
			print(Fore.RED+"error in create_directory")
			print(str(e))
			InsertWebAppException("Python","create_directory",os.path.basename(__file__),str(e))
			logging.debug(e)
	else:
		pass
	return folder_path




conf_file_path = 'C:\\Client\\Conf_Path.txt'
source = '\\'.join(get_file_path(conf_file_path)['ChannelGenreMappingSheet'].split('\\')[:-1])
dest = create_directory(get_file_path(conf_file_path)['ChannelGenreMappingSheet'])

'''creating directory for later use'''
create_directory(get_file_path(conf_file_path)['MasterDataFilePath'])



'''-----------------------harnath---------------------------------------------------------------------------------------'''
def master_mapping_download(conf_file_path):
	filespath_list=[]
	path_dic=get_file_path(conf_file_path)
	master_path= path_dic["MasterDataFilePath"]
	for (root,dirs,files) in os.walk(master_path, topdown=True):
		#print(files) 
		break
	for names in files:
		filespath_list.append(master_path+names)
	channel_mapping_path=path_dic["ChannelGenreMappingSheet"]
	for (root,dirs,files) in os.walk(channel_mapping_path, topdown=True):
		#print(files) 
		break
	for names in files:
		filespath_list.append(channel_mapping_path+names)
	blog=download_file(filespath_list)
	return blog

def time_stamp_master_mapping(conf_file_path):
    master_dic={}
    master_path_dic={}
    path_dic=get_file_path(conf_file_path)
    
    master_path= path_dic["MasterDataFilePath"]
    for (root,dirs,files) in os.walk(master_path, topdown=True):
        #print(files) 
        break
    if(len(files)):
        for i in range(len(files)):   
            master_path_dic[files[i]]=str(time.ctime(os.path.getctime(master_path+'\\'+str(files[i]))))

    channel_mapping_dic={}
    channel_mapping_path=path_dic["ChannelGenreMappingSheet"]
    for (root,dirs,files) in os.walk(channel_mapping_path, topdown=True):
        #print(files) 
        break
    if(len(files)):
        for i in range(len(files)):   
            channel_mapping_dic[files[i]]=str(time.ctime(os.path.getctime(channel_mapping_path+'\\'+str(files[i]))))

    master_dic['master_data']=master_path_dic
    master_dic['ChannelGenreMappingSheet']=channel_mapping_dic
    return(master_dic)
'''-----------------------------------harnath---------------------------------------------------------------------------------------------'''

def download_file(file_paths):
	"""
	Expects From UI: file_paths   <type: list>   #"C:\\Banglore\\Google\\120719141405\\1\\aditi_patil\\Closed Account Cases.xlsx"
	"""
	if len(file_paths) > 1:
		with ZipFile("WMDemo.zip", 'w') as zi:
			for file in file_paths:
				zi.write(file,basename(file))
			zi.close()
		with open("WMDemo.zip", 'rb') as fo:
			blob = base64.b64encode(fo.read())
			fo.close()
		# print(blob)
		return (blob)
	else:
		with open(file_paths[0].split("\\")[-1], 'rb') as fo:
			blob = base64.b64encode(fo.read())
			fo.close()
		# print(blob)
		return (blob)
	return ("Files Downloaded!")



"""====================================================Buying Basket=========================================================="""

def path_conf_helper(PlanFilePath, result):

	conf_path = PlanFilePath.replace('<','').replace('>', '')
	my_list = ['Location', 'Client', 'CampaignId', 'Version', 'Planner']
	res = {k:v for k, v in zip(my_list, result[0])}
	rs = [f for f in conf_path.split('\\')]
	r = [ele for ele in rs if ele != ""]
	if res['Planner'] and res['Planner'] != None:
		res['Planner'] = res['Planner'][:res['Planner'].index('@')]
		res['Planner'] = res['Planner'].replace('.', ' ')
	else:
		res['Planner'] = 'Sample_User'
		return ('Planner is NULL. Creating a ',res['Planner'])
		
	for i,ele in enumerate(r):
		r[i] = str(res[ele])
	r_path = '\\'.join(r)
	try:
		os.makedirs(get_file_path(conf_file_path)['PlanFilePath']+'\\'+r_path+'\\Dump')
	except Exception as e:
		print(Fore.RED+"error in path_conf_helper")
		print(str(e))
		InsertWebAppException("Python","path_conf_helper",os.path.basename(__file__),str(e))
	return get_file_path(conf_file_path)['PlanFilePath']+'\\'+r_path+'\\Dump'

"""================================================Buying Basket End============================================================"""

def insert_master_data(file_path):
	'''
	Helper Function For Master Data Settings
	'''
	# file_path = 'C:\\Users\\algonox\\Desktop\\WaveMaker'+file_name
	wb = xlrd.open_workbook(file_path)
	sheet = wb.sheet_by_index(0)
	col0_values = []
	col1_values = []
	for i in range(1,sheet.nrows):
		col0_values.append(sheet.cell_value(i,0))
		try:
			col1_values.append(sheet.cell_value(i,1))
		except Exception as e:
			print(Fore.RED+"error in insert_master_data")
			print(str(e))
			InsertWebAppException("Python","insert_master_data",os.path.basename(__file__),str(e))
			pass
	return col0_values, col1_values

def get_uniq(file_path,idx1, idx2, sheet_name):
    """
    Helper function
    """
    global columns_list
    df = pd.read_excel(file_path, sheet_name = sheet_name)
    columns_list = list(df.columns.values)
    new_df = df[[columns_list[idx1], columns_list[idx2]]]
    df1 = new_df.drop_duplicates((columns_list[idx1], columns_list[idx2]), keep='first')

    return ([(ele[0],ele[1]) for i, ele in df1.iterrows()])

def insert_client_lead(file_path, idx1, idx2, cl, sheet_name):
    df = pd.read_excel(file_path, sheet_name = sheet_name)
    columns_list = list(df.columns.values)
    new_df = df[[columns_list[idx1], columns_list[idx2], cl]]
    df = new_df.drop_duplicates(keep = 'first')
    
    return ([(ele[0],ele[1], ele[2]) for i, ele in df.iterrows()])

def get_empty_rows(path, sheet_name, column_name):
    """
    Get Empty cells: returns <type: list>
    """
    df = pd.read_excel(path, sheet_name)
    empty_rows = []
    for ele in df.index[df[column_name].isnull()].tolist():
        empty_rows.append(ele+2)
    return empty_rows


def move_file(source, dest, onlyfiles):
    now = datetime.datetime.now()

    now_ = str(now)
    date_time = now_.replace('-', '').replace(' ', '_').replace(':', '')
    try:
        for f in onlyfiles:
            print(f)
            dst = str(f.split('.')[0]+ '_' + date_time +'.'+f.split('.')[-1])
            src = source + '\\' + f 
            dst = source + '\\' + dst
            # print(dst) 
            os.rename(src, dst)
            shutil.move(dst, dest)
    except Exception as e:
        #logging.debug(e)
        print(e)
        return ("Error in moving file!")
    return ("File moved to Archive!")


def getListOfFiles(dirName):
    # create a list of file and sub directories 
    # names in the given directory 
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory 
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            allFiles.append(fullPath)
                
    return allFiles