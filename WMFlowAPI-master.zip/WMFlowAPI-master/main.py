from flask import Flask, redirect, url_for,jsonify,render_template,request
from flask_cors import CORS
import json
#from sqlconnectionsdevelopment import Location_Data,Client_Data,Client_Lead_Generation,Create_Profile_function,Create_Profile_freeze_function,Create_plane_Function,Create_plan_Button_function,Dashboard_Table_One_function,Dashboard_Table_Two_function,Complete_Button_Function,Create_plan_freeze_function,login_function,ongoing_gobutton_function,ongoing_client,comleted_gobutton_function,ongoing_prioritize_button_function,logout_function,Primary_Tg,Base_Tg,Campaign_Market,End_Week,Barc_freeze_function,useremail_function,planner_client_function,useremail_del_function,add_save_function,delete_save_function,BARC_just_confirm_button_function,BARC_update_confirm_button_function,plan_selection_function,replan_campaign,buying_basket_freeze_function,master_roles_and_Privileges_function, path_conf_helper, get_file_path, SQL_Connect, insert_master_data,Dashboard_Table_One_Data_flag,Dashboard_Table_Two_Data_flag
from Algonox_Rover_toadd import *
from datetime import datetime
import ast
import base64
import os
from os import listdir,path
from os.path import isfile, join
import shutil
import xlrd
import ntpath
import shutil
from zipfile import ZipFile
from colorama import Fore, Back, Style
from colorama import init

app = Flask(__name__)
init()
cors = CORS(app)

conf_file_path=str(os.getcwd())+'\\Conf_Path.json'
path_dic=get_file_path(conf_file_path)
#----------------------------------login page------------------------------------------
pointer=SQL_Connect()
cursor=pointer.cursor()
conf_file_path = 'C:\\Client\\Conf_Path.txt'
source_channel = '\\'.join(get_file_path(conf_file_path)['ChannelGenreMappingSheet'].split('\\')[:-1])
dest_channel = get_file_path(conf_file_path)['ChannelGenreMappingSheet']
source_masterdata = '\\'.join(get_file_path(conf_file_path)['MasterDataFilePath'].split('\\')[:-1])
dest_masterdata = get_file_path(conf_file_path)['MasterDataFilePath']


@app.route("/",methods=["GET", "POST"])
def hello():
	return "HIIIIII"
@app.route("/Login_page",methods=["GET", "POST"])
def Login_page():
	data=request.form
	print("AD dataaaa-->",data)
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN +'email and password from ui is ',d)
	login_data=login_function_1(d)
	print(Fore.WHITE+'login data for user is',login_data)
	return jsonify(login_data)

@app.route("/Login_ad", methods=["POST", "GET"])
def Login_ad():
	ad_cred = request.form
	print("Hit Success!",ad_cred)
	ad_dict = ad_cred.to_dict()
	print('responce from ac-----------------')
	print(ad_dict)
	ad_dict = json.loads(ad_dict['file'])
	ad_data = login_function_ad(ad_dict)
	# print("ad_dataaaa", ad_data)
	return ad_data
#---------------------------------logout button-----------------------------------------------------------------
@app.route("/logout_button",methods=["GET", "POST"])
def logout_button():
	data=request.form
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'provided logout data is ',d)
	logout_data=logout_function(d)
	print(Fore.WHITE+logout_data)
	return jsonify("logoutsuccess")

#------------------------palnner profile page----------------------------------------------------------------	
	
# drop down values for planner profile page
@app.route("/Location_Data_Request",methods=["GET","POST"])
def Location_Data_Request(): 
	data=request.form
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+"user id for the location is ",d)
	Location_Data=Location_function()
	print(Fore.WHITE+'location for the given user are ',Location_Data)
	return jsonify(Location_Data)

# Drop down values for Client 
@app.route("/Client_Data_Request",methods=["GET","POST"])
def Client_Data_Request():
	data=request.form
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'location id for client data is ',d)
	Client_Data=Client_function(d)
	print(Fore.WHITE+'Clients present for this location are :',Client_Data)
	return jsonify(Client_Data)

#drop down values for Client lead
@app.route("/Planner_Profile_Client_Lead",methods=["GET", "POST"])
def Planner_Profile_Client_Lead():
	data=request.form
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'client ids for Client leads are :',d)
	Client_Lead_Data=Client_Lead_function(d)
	print(Fore.WHITE+'Client leads for selected clients are :',Client_Lead_Data)
	return jsonify(Client_Lead_Data)

#updating data into data base
@app.route("/Create_Profile",methods=["GET", "POST"])
def Create_Profile():
	data=request.form
	profileid_dic={}
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'recived record for the profile is:',d)
	Create_Profile_Ids=Create_Profile_function(d)
	profileid_dic=Create_Profile_Ids        #tell to ui keyword change
	print(Fore.WHITE+'Generated profile id for this user is ',profileid_dic)
	return jsonify(profileid_dic)	

#data to Profile_freeze stage
@app.route("/Create_Profile_freeze",methods=["GET", "POST"])
def Create_Profile_freeze():
	data=request.form
	data = data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'profile id for freeze data is ',d)
	Create_Profile_freeze_data=Create_Profile_freeze_function(d)
	print(Fore.WHITE+'freeze data for this user is ',Create_Profile_freeze_data)
	return jsonify(Create_Profile_freeze_data)

#------------------------------------create plane page--------------------------------

#create plane drop down data
@app.route("/Create_plan",methods=["GET","POST"])
def Create_plane():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'user id for createplane is ',d)
	Create_plane_data=Create_plane_Function(d)
	print(Create_plane_data)
	print(Fore.WHITE+'drop downdata sent')
	return jsonify(Create_plane_data)

#updating data to data base
@app.route("/Create_plan_button",methods=["GET","POST"])
def Create_plan_button():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+"plan record to be inserted is ",d)
	Create_plan_Button_ids=Create_plan_Button_function(d)
	print(Fore.WHITE+'id for generated plan is:',Create_plan_Button_ids)
	
	return jsonify(Create_plan_Button_ids)

@app.route("/Create_plane_Freeze",methods=["GET","POST"])
def Create_plan_freeze():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'Plan id for freeze data is :',d)
	Create_plan_freeze_data=Create_plan_freeze_function(d)
	print(Fore.WHITE+'freeze data for this plan is :',Create_plan_freeze_data)
	return jsonify(Create_plan_freeze_data)

#--------------------------dashboard page------------------------------------------------

@app.route("/Dashboard_screen_load",methods=["GET","POST"])
def Dashboard_screen_load():
	data=request.form
	data=data.to_dict()
	print(Fore.GREEN+"dashbord onscreen load actived ",data)
	Dashboard_data={}
	d=json.loads(data['file'])
	Dashboard_data=Dashboard_Table_flag(d)
	print(Fore.WHITE+"\n top 10 plans sent \n")
	#print("top 10 plans are :",Dashboard_data)
	return jsonify(Dashboard_data)

@app.route("/Dashboard_Table_One",methods=["GET","POST"])
def	Dashboard_Table_One():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'start,end dates for plans are : ',d)
	d['startdate']=datetime.strptime(d['startdate'],'%Y-%m-%d').date()
	d['enddate']=datetime.strptime(d['enddate'],'%Y-%m-%d').date()
	Dashboard_Data=Dashboard_Table_dates(d)
	print(Fore.WHITE+"\n plans in between the given range sent \n " )
	print("plans in between the given range are :",Dashboard_Data)
	return jsonify(Dashboard_Data)

@app.route("/Dashboard_Complete_Button",methods=["GET","POST"])
def Complete_Button():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+"plan id for the plan to be complete",d)
	Complete_Button_Function(d)
	if(d['startdate']=='' and d['enddate']==''):
		temp_dic={}
		temp_dic['user_id']=d['user_id']
		temp_dic['isdefult']=True
		Dashboard_Data=Dashboard_Table_flag(temp_dic)

	else:
		d['startdate']=datetime.strptime(d['startdate'],'%Y-%m-%d').date()
		d['enddate']=datetime.strptime(d['enddate'],'%Y-%m-%d').date()
		Dashboard_Data=Dashboard_Table_dates(d)
	print(Fore.WHITE+"\n plans in between the given range sent \n " )
	#print("plans in between the given range are :",Dashboard_Data)
	return jsonify(Dashboard_Data)

#-------------------------ongoing page----------------------------------------------------------------------------------
@app.route("/ongoing_client_request",methods=["GET", "POST"])
def ongoing_client_request():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	Create_plane_Function_data={}
	print(Fore.GREEN+"client data required for user number is :",d)
	Create_plane_Function_data['Client']=GetClientAndBrandForUser(d)
	Create_plane_Function_data['records']=ongoing_screenload_function(d)
	if Create_plane_Function_data['records']:
		pass
	else:
		Create_plane_Function_data['records']=[]
	print(Fore.WHITE+'\n records for the given dates,clients and brands for the user are send \n')
	print('records for the given dates,clients and brands for the user is :',Create_plane_Function_data)
	return jsonify(Create_plane_Function_data)

@app.route("/ongoing_gobutton",methods=["GET", "POST"])
def ongoing_gobutton():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+"search perameters for plans are :",d)
	ongoing_gobutton_data=ongoing_gobutton_function(d)
	print(Fore.WHITE+'\n plans as per the search sent \n')
	#print('plans as per the search are :',ongoing_gobutton_data)
	return jsonify(ongoing_gobutton_data)

@app.route("/ongoing_prioritize_button_1",methods=["GET", "POST"])
def ongoing_prioritize_button1():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	#print('inside rout',d)
	print(Fore.GREEN+'prioritize bit user and plane ids ',d)
	if(d['startdate'] or d['enddate'] or d['clientclass'] or d['brandclass'] or d['Campaignid']):
		d['IsDefault']=False

	ongoing_prioritize_button_data=ongoing_prioritize_button_function(d)
	#print('records for the given dates,clients and brands for the user is :',ongoing_prioritize_button_data)
	print(Fore.WHITE+' \n records for the given dates,clients and brands for the user are sent \n') 
	return jsonify(ongoing_prioritize_button_data)

#------------------------------completed page------------------------------------------------------------------------

@app.route("/completed_client_request",methods=["GET", "POST"])
def completed_client_request():
	data=request.form
	data=data.to_dict()
	Completed_plane_Function_data={}
	d=json.loads(data['file'])
	print(Fore.GREEN+"onscreen load activated and user id is ",d)
	Completed_plane_Function_data['Client']=GetClientAndBrandForUser(d)
	Completed_plane_Function_data['records']=comleted_screenload_function(d)
	return jsonify(Completed_plane_Function_data)

@app.route("/completed_gobutton",methods=["GET", "POST"])
def completed_gobutton():
	data=request.form
	data=data.to_dict()
	print(Fore.GREEN+'data inside ongoing_gobutton is',data)
	d=json.loads(data['file'])
	completed_gobutton_data=comleted_gobutton_function(d)
	return jsonify(completed_gobutton_data)

#----------------------------------BARC EVALUTION-----------------------------------------------------------------------------------

@app.route("/BARC_Evalution_edit_button",methods=["GET","POST"])
def BARC_Evalution_edit_button(): 
	dic={}
	data=request.form
	dic['Campaign_Market_dt'] =Campaign_Market()
	dic['Primary_Tg_dt'] =Primary_Tg()
	dic['Base_Tg_dt'] =Base_Tg()
	dic['End_Week_dt'] =End_Week()
	#print('barc drop down data send',dic)
	print(Fore.WHITE+'\n barc drop down data send \n')	
	return jsonify(dic)

@app.route("/Barc_Plan_Freeze",methods=["GET","POST"])
def Create_barc_freeze():
	data=request.form
	data=data.to_dict()
	dic={}
	d=json.loads(data['file'])
	print(Fore.GREEN+'Create_plane_Freeze data from ui ',d)
	Barc_freeze_data=Barc_freeze_function(d)
	dic['planid']=d['planId']
	version=version_function(dic)
	Barc_freeze_data['PathSelection']=int(version['PathSelection'])
	print(Fore.WHITE+'data freezed ',Barc_freeze_data)
	return jsonify(Barc_freeze_data)

@app.route("/BARC_confirm_button",methods=["GET","POST"])
def BARC_just_confirm_button():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print('data from ui for barc conform button ',d)
	# if(d['edit']==False):
	# 	status=BARC_just_confirm_button_function(d)
	# 	print(Fore.WHITE+status)
	# 	return status
	# else:
	# 	status=BARC_update_confirm_button_function(d)
	# 	print(Fore.WHITE+status)
	# 	return status
	status = (BARC_just_confirm_button_function(d)) if (d['edit']==False) else (BARC_update_confirm_button_function(d))
	print(Fore.WHITE+status)
	return status

#--------------------Add or remove ------------------------

@app.route("/add_planner_onload",methods=["GET","POST"])
def add_planner_onload():
	data=request.form
	data=data.to_dict()
	dic={}
	d=json.loads(data['file'])
	print(Fore.GREEN+'client request for the user id is ',d)
	useremail_data=useremail_function()
	planner_client_function_data=planner_client_function(d)
	dic['clients'] =planner_client_function_data
	dic['emails']=useremail_data
	print(Fore.WHITE+'\n data of clien,brands and emails send \n')
	return jsonify(dic)

@app.route("/delete_planner_onload",methods=["GET","POST"])
def delete_planner_onload():
	data=request.form
	data=data.to_dict()
	data=json.loads(data['file'])
	d=data['user_id']
	print(Fore.GREEN+'user id for the emails are',d)
	useremail_data=useremail_del_function(d)
	return jsonify(useremail_data)

@app.route("/add_save_button",methods=["GET","POST"])
def add_save_button():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'user id and client id for assign save is',d)
	save_data=add_save_function(d)
	print('date change status is ',save_data)
	return jsonify(save_data)

@app.route("/delete_save_button",methods=["GET","POST"])
def delete_save_button():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+'user id and client id for delete save is',d)
	delete_data=delete_save_function(d)
	return jsonify(delete_data)

#------------------------------------buying basket----------------------------------------------------------------------------------

@app.route("/version_for_plan",methods=["GET","POST"])
def version_for_plan():
	data=request.form
	data=data.to_dict()
	d=json.loads(data['file'])
	print(Fore.GREEN+"plan id passed for the version is ",d)
	version_data=version_function(d)
	print(Fore.WHITE+"version for the plan id passed is ",version_data)
	return jsonify(version_data)

@app.route("/plan_selection_button",methods=["GET","POST"])
def plan_selection_button():
	# data = request.json
	data=request.form
	data =data.to_dict()
	data=json.loads(data['file'])
	print(Fore.GREEN+'data recived for Plan selection is ',data)
	message = plan_selection_function_1(data)
	return jsonify({"Status": message})

@app.route("/re_plan_campaign_1",methods=["GET","POST"])
def re_plan_campaign():
	raw_data=request.form
	raw_data = raw_data.to_dict()
	print(Fore.GREEN+"campain id to be replaned is",raw_data)
	data=json.loads(raw_data['file'])
	response_data = replan_campaign(data)
	print(Fore.WHITE+'new plan id for the selected plan is :',response_data)
	
	return jsonify(response_data)

@app.route("/buying_basket_freeze",methods=["GET","POST"])
def buying_basket_freeze():
	data=request.form
	data = data.to_dict()
	data=json.loads(data['file'])
	print(Fore.GREEN+"plan id for buying basket freeze",data)
	buying_basket_freeze_data=buying_basket_freeze_function(data)
	print(Fore.WHITE+'buying_basket_freeze data is ',buying_basket_freeze_data)
	return jsonify(buying_basket_freeze_data)

#--------------------------------------master roles -----------------------------------------------------------

@app.route("/master_roles_and_Privileges",methods=["GET","POST"])
def master_roles_and_Privileges():
	raw_data=request.form
	#raw_data = raw_data.to_dict()
	#print(raw_data)
	#data=json.loads(raw_data['file'])
	master_roles_and_Privileges_data=master_roles_and_Privileges_function()
	print('data send')
	return jsonify(master_roles_and_Privileges_data)

@app.route("/master_roles_and_Privileges_button",methods=["GET","POST"])
def master_roles_and_Privileges_button():
	raw_data=request.form
	raw_data = raw_data.to_dict()
	print(raw_data)
	d=json.loads(raw_data['file'])
	master_role_update_function(d)
	master_roles_and_Privileges_data=master_roles_and_Privileges_function()
	print('data updates and sent')
	return jsonify(master_roles_and_Privileges_data)

#-------------------------Error handling-------------------------------------------------------------------------------

@app.route("/Error_handling",methods=["GET","POST"])
def Error_handling():
	raw_data=request.form
	raw_data = raw_data.to_dict()
	print(raw_data)
	d=json.loads(raw_data['file'])
	InsertWebAppException("Web App",str(d['function']),str(d['page']),str(d['error']))
	return jsonify("update")
#------------------------------------download(harnath)-------------------------------------------------------------------
@app.route("/master_mapping_files_time_stamps",methods=["GET","POST"])
def master_mapping_files_time_stamps():
	data=request.form
	master_mapping_files_time_stamps_data= time_stamp_master_mapping(conf_file_path)
	return (jsonify(master_mapping_files_time_stamps_data))

@app.route("/download_master_mapping_files",methods=["GET","POST"])
def download_master_mapping_files():
	raw_data=request.form
	master_mapping_download_data=master_mapping_download(conf_file_path)
	return master_mapping_download_data

'''------------------------------------------------------------Santosh-----------------------------------------------------------'''
"""==========================================================Buying Basket======================================================="""
@app.route('/Buying_basket', methods=['POST', 'GET'])
 
# def Buying_basket():
# 	'''
# 	Expects From UI: PlanId, UserId, Blob_data, Category

# 	Sends to database: PlanId, UserId, File_path

# 	returns: File_name 
# 	'''

# 	form_data = request.form
# 	# data = form_data
# 	# print('form_data -> ', form_data)
# 	form_data=form_data.to_dict()
# 	data = ast.literal_eval(form_data['file'])  #json.loads(form_data['file'])
# 	blob_data = data['blob'].split(',')[1]
# 	# print('blob data -> ',blob_data)
# 	file_name = data['filename']
# 	PlanId = data['plan_id']
# 	UserId = data['user_id']
# 	Category = data['category']

# 	'''-----------fetch_data_from_database------------------'''
# 	cursor.execute("exec [dbo].[GetPlanInfo] @PlanId=?",(PlanId))
# 	result = cursor.fetchall()
# 	'''-----------------------------------------------------'''

# 	file_path = path_conf_helper(get_file_path(conf_file_path)['PlanFilePathFormat'], result)+'\\'+file_name
# 	print('plan_id -> ', PlanId)
# 	print('file_name -> ', file_name)
# 	print('User_id -> ', UserId)
# 	with open(file_path,'wb') as f:
# 		bd = base64.b64decode(blob_data)
# 		f.write(bd)
# 		f.close()

# 	"""
# 	Below code can be made functional..
# 	"""
# 	if Category == 'acceleratedfile':
# 		try:
# 			conf_headers_accelerate = get_file_path(conf_file_path)["AcceleratedFile"]
# 			conf_headers_accelerate = [x.lower().strip() for x in conf_headers_accelerate]
# 		except Exception:
# 			return ("Please mention the headers in the conf_path")
# 		try:
# 			xl_headers_accelerate = list(pd.read_excel(file_path, sheet_name = 0))
# 			xl_headers_accelerate = [x.lower().strip() for x in xl_headers_accelerate]
# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the Sheet format")

# 		if xl_headers_accelerate == conf_headers_accelerate:
# 			cursor.execute("exec [dbo].[UpdateAcceleratedFilePath] @PlanId=?,@UserId=?,@AcceleratedFilePath=?",(PlanId, UserId, file_path))
# 			cursor.commit()
# 			return ('Path inserted Succesfully')
# 		else:
# 			return ("Headers did not match!")

# 	elif Category == 'buyingbasket':
# 		try:
# 			conf_headers_buying_basket = get_file_path(conf_file_path)["BuyingBasket"]
# 			conf_headers_buying_basket = [x.lower().strip() for x in conf_headers_buying_basket]
# 		except Exception:
# 			return ("Please mention the headers in the conf_path")
# 		try:
# 			xl_headers_buying_basket = list(pd.read_excel(file_path, sheet_name = 0))
# 			xl_headers_buying_basket = [x.lower().strip() for x in xl_headers_buying_basket]
# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the Sheet format")

# 		if xl_headers_buying_basket == conf_headers_buying_basket:
# 			cursor.execute("exec [dbo].[UpdatePlanForBuyingBasketFile] @PlanId=?,@UserId=?,@BuyingBasketFilePath=?",(PlanId, UserId, file_path))
# 			cursor.commit()
# 			return ('Path inserted Succesfully')
# 		else:
# 			return ("Headers did not match!")

# 	elif Category == 'spilloversheet':
# 		try:
# 			conf_headers_spillover = get_file_path(conf_file_path)["SpilloverSheet"]
# 			conf_headers_spillover = [x.lower().strip() for x in conf_headers_spillover]
# 		except Exception:
# 			return ("Please mention the headers in the conf_path")
# 		try:
# 			df = pd.read_excel(file_path)
# 			xl_headers_spillover = [x.lower().strip() for x in df.loc[6][0]]
# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the Sheet format")
				
# 		if xl_headers_spillover == conf_headers_spillover:
# 			cursor.execute("exec [dbo].[UpdatePlanForSpillOverSheetFilePath] @PlanId=?,@UserId=?,@SpillOverSheetFilePath=?",(PlanId, UserId, file_path))
# 			cursor.commit()
# 			return ("Path inserted Succesfully")
# 		else:
# 			return ("Header format did not match!")

# 	elif Category == 'budgetallocation':
# 		try:
# 			conf_headers_budget_allocation = get_file_path(conf_file_path)["BudgetAllocation"]
# 			conf_headers_budget_allocation = [x.lower().strip() for x in conf_headers_budget_allocation]
# 		except Exception:
# 			return ("Please mention the headers in the conf_path")
# 		try:
# 			xl_headers_budget_allocation = list(pd.read_excel(file_path, sheet_name = 0))
# 			xl_headers_budget_allocation = [x.lower().strip() for x in xl_headers_budget_allocation]
# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the Sheet format")

# 		if xl_headers_budget_allocation == conf_headers_budget_allocation:
# 			cursor.execute("exec [dbo].[UpdatePlanForBudgetAllocationFilePath] @PlanId=?,@UserId=?,@BudgetAllocationFilePath=?",(PlanId, UserId, file_path))
# 			cursor.commit()
# 			return ("Path inserted Succesfully")
# 		else:
# 			return ("Header format did not match!")
			
# 	else:
# 		return ('Category is incorrect!')
# 	return (file_name)

def Buying_basket():
	'''
	Expects From UI: PlanId, UserId, Blob_data, Category

	Sends to database: PlanId, UserId, File_path

	returns: File_name 
	'''

	form_data = request.form
	# data = form_data
	# print('form_data -> ', form_data)
	form_data=form_data.to_dict()
	data = ast.literal_eval(form_data['file'])  #json.loads(form_data['file'])
	blob_data = data['blob'].split(',')[1]
	# print('blob data -> ',blob_data)
	file_name = data['filename']
	PlanId = data['plan_id']
	UserId = data['user_id']
	Category = data['category']

	'''-----------fetch_data_from_database------------------'''
	try:
		cursor.execute("exec [dbo].[GetPlanInfo] @PlanId=?",(PlanId))
		result = cursor.fetchall()
	except Exception as e:
		print(e)
		return ("Database error while fetching data!")
	'''-----------------------------------------------------'''

	file_path = path_conf_helper(get_file_path(conf_file_path)['PlanFilePathFormat'], result)+'\\'+file_name
	print('file_path->', file_path)
	print('category->',Category)
	print('plan_id -> ', PlanId)
	print('file_name -> ', file_name)
	print('User_id -> ', UserId)
	with open(file_path,'wb') as f:
		bd = base64.b64decode(blob_data)
		f.write(bd)
		f.close()

	"""
	Below code can be made functional..
	"""
	if Category == 'acceleratedfile':
		try:
			conf_headers_accelerate = get_file_path(conf_file_path)["AcceleratedFile"]
			conf_headers_accelerate = [x.lower().strip() for x in conf_headers_accelerate]
		except Exception:
			return ("Please mention the headers in the conf_path")
		try:
			xl_headers_accelerate = list(pd.read_excel(file_path, sheet_name = 0))
			xl_headers_accelerate = [x.lower().strip() for x in xl_headers_accelerate]
		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the Sheet format")

		if xl_headers_accelerate == conf_headers_accelerate:
			cursor.execute("exec [dbo].[UpdateAcceleratorFilePath] @PlanId=?,@UserId=?,@AcceleratorFilePath=?",(PlanId, UserId, file_path))
			cursor.commit()
			return ('Path inserted Succesfully')
		else:
			return ("Headers did not match!")

	elif Category == 'buyingbasket':
		try:
			conf_headers_buying_basket = get_file_path(conf_file_path)["BuyingBasket"]
			conf_headers_buying_basket = [x.lower().strip() for x in conf_headers_buying_basket]
		except Exception:
			return ("Please mention the headers in the conf_path")
		try:
			xl_headers_buying_basket = list(pd.read_excel(file_path, sheet_name = 0))
			xl_headers_buying_basket = [x.lower().strip() for x in xl_headers_buying_basket]
		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the Sheet format")

		if xl_headers_buying_basket == conf_headers_buying_basket:
			cursor.execute("exec [dbo].[UpdatePlanForBuyingBasketFile] @PlanId=?,@UserId=?,@BuyingBasketFilePath=?",(PlanId, UserId, file_path))
			cursor.commit()
			return ('Path inserted Succesfully')
		else:
			return ("Headers did not match!")

	elif Category == 'spilloversheet':
		try:
			conf_headers_spillover = get_file_path(conf_file_path)["SpilloverSheet"]
			conf_headers_spillover = [x.lower().strip() for x in conf_headers_spillover]
		except Exception:
			return ("Please mention the headers in the conf_path")
		try:
			df = pd.read_excel(file_path)
			xl_headers_spillover = [df.loc[6][0].lower().strip()]
		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the Sheet format")
				
		if xl_headers_spillover == conf_headers_spillover:
			cursor.execute("exec [dbo].[UpdatePlanForSpillOverSheetFilePath] @PlanId=?,@UserId=?,@SpillOverSheetFilePath=?",(PlanId, UserId, file_path))
			cursor.commit()
			return ("Path inserted Succesfully")
		else:
			return ("Header format did not match!")

	elif Category == 'budgetallocation':
		
		try:
			conf_headers_budget_allocation = get_file_path(conf_file_path)["BudgetAllocation"]
			conf_headers_budget_allocation = [x.lower().strip() for x in conf_headers_budget_allocation]
		except Exception:
			return ("Please mention the headers in the conf_path")
		try:
			xl_headers_budget_allocation = list(pd.read_excel(file_path, sheet_name = 0))
			xl_headers_budget_allocation = [x.lower().strip() for x in xl_headers_budget_allocation]
		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the Sheet format")
		print(conf_headers_budget_allocation, xl_headers_budget_allocation)
		if xl_headers_budget_allocation == conf_headers_budget_allocation:
			cursor.execute("exec [dbo].[UpdatePlanForBudgetAllocationFilePath] @PlanId=?,@UserId=?,@BudgetAllocationFilePath=?",(PlanId, UserId, file_path))
			cursor.commit()
			return ("Path inserted Succesfully")
		else:
			return ("Header format did not match!")
			
	else:
		return ('Category is incorrect!')
	return (file_name)

"""==================================================Buying Basket End======================================================"""

# @app.route('/master_data_settings', methods = ['GET', 'POST'])
# def master_data_settings():

# 	'''
# 	ui_data = user_id, category, blob_data  

# 	Location: location_name, user_id
# 	Client: client_name, location_name, user_id
# 	Brand :Brand_name, client_name, User_id
# 	TG: Target_group, User_id
# 	Campaign_markets: campaign_market_name, user_id
# 	'''
# 	ui_data = request.form
# 	ui_data = ui_data.to_dict()
# 	# print('ui_dataaaaaa',ui_data)
# 	data = ast.literal_eval(ui_data['file'])
# 	file_name = data['filename']
# 	blob_data = data['blob'].split(',')[1]

# 	# print('blob_data -> ', blob_data)
# 	category = data['category']
# 	print('category -> ', category)
# 	user_id = data['user_id']
# #---------------------------------------------------------------------------------
# 	try:
# 		onlyfiles = [f for f in listdir(source_1) if isfile(join(source_1, f))]
# 	except Exception as e:
# 		print(e)
# 		return ("Folder or file not found in channel sheet mapping")
			
# 	for f in onlyfiles:
# 		try:
# 			shutil.move(source_1+'\\'+f, dest_1)
# 		except Exception as e:
# 			#logging.debug(e)
# 			print(e)
# 			return ("Unable to Archive Files!\n Maybe a permission error.")


# #------------------------------------------------------------------------------------
# 	file_path = create_directory(get_file_path(conf_file_path)['MasterDataFilePath'])+file_name
# 	with open(file_path,'wb') as f:
# 		bd = base64.b64decode(blob_data.encode('utf-8'))
# 		f.write(bd)
# 		f.close()


# 	if category == 'masterdata':
# 		try:

# 			xl_headers_tg_raw = list(pd.read_excel(file_path, sheet_name = 0))
# 			xl_headers_tg = [x.lower().strip() for x in xl_headers_tg_raw]
# 			xl_headers_clients_lead_raw = list(pd.read_excel(file_path, sheet_name = 1))
# 			xl_headers_clients_lead = [x.lower().strip() for x in xl_headers_clients_lead_raw]
# 			xl_headers_markets_raw = list(pd.read_excel(file_path, sheet_name = 2))
# 			xl_headers_markets = [x.lower().strip() for x in xl_headers_markets_raw]
# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the sheet format", xl_headers_tg_raw)

# 		try:

# 			conf_headers_clients_lead = get_file_path(conf_file_path)["MasterDataFormatLocationClients"]
# 			conf_headers_clients_lead = [x.lower().strip() for x in conf_headers_clients_lead]
# 			conf_headers_tg = get_file_path(conf_file_path)["MasterDataFormatTG"]
# 			conf_headers_tg = [x.lower().strip() for x in conf_headers_tg]
# 			conf_headers_markets = get_file_path(conf_file_path)["Markets"]
# 			conf_headers_markets = [x.lower().strip() for x in conf_headers_markets]
# 		except Exception as e:
# 			print(e)
# 			return ("Please mention the excel headers in the conf_path file!")

# 		if xl_headers_clients_lead == conf_headers_clients_lead:
# 			wb = xlrd.open_workbook(file_path)
# 			loc_sheet = wb.sheet_by_index(1)
# 			location =list(set([loc_sheet.cell_value(i,0) for i in range(1, loc_sheet.nrows)]))
# 			for ele in location:
# 				# print("Inserting Location.. ", ele)
# 				cursor.execute("exec [dbo].[UpsertLocation] @LocationName=?,@UserId=?",(str(ele).strip(), user_id))
# 				cursor.commit()
# 			for ele in get_uniq(file_path, 0, 1, sheet_name = 1):
# 				# print("Inserting Client.. ", ele[0], ele[1])
# 				cursor.execute("exec [dbo].[UpsertClient] @LocationName=?,@ClientName=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
# 				cursor.commit()
# 			for ele in get_uniq(file_path, 1, 2, sheet_name = 1):
# 				# print("Inserting Brand.. ", ele[0], ele[1])
# 				cursor.execute("exec [dbo].[UpsertBrand] @ClientName=?,@BrandName=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
# 				cursor.commit()
# 			for ele in insert_client_lead(file_path, 0, 1, "Client Leads1", 1):
# 				try:
# 					# print("Inserting Client Leads1.. ", ele[0], ele[1], ele[2])
# 					cursor.execute("exec [dbo].[InsertClientLeadFromMasterData] @LocationName=?,@ClientName=?,@UserEmailId=?,@AdminUserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), str(ele[2]).strip(), user_id))
# 					cursor.commit()
# 				except Exception as e:
# 					print(e)
# 					return ("Insertion Error occured!!")

# 			for ele in insert_client_lead(file_path, 0, 1, "Client Leads2", 1):
# 				try:
# 					# print("Inserting Client Leads2.. ", ele[0], ele[1], ele[2])
# 					cursor.execute("exec [dbo].[InsertClientLeadFromMasterData] @LocationName=?,@ClientName=?,@UserEmailId=?,@AdminUserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), str(ele[2]).strip(), user_id))
# 					cursor.commit()
# 				except Exception as e:
# 					print(e)
# 					return ("Insertion Error occured!!")
# 		else:
# 			return ("Incorrect header format!!")
		
# 		if xl_headers_tg == conf_headers_tg:
# 			for ele in get_uniq(file_path, 0, 1, sheet_name = 0):
# 				# print("Inserting TG.. ", ele[0], ele[1])
# 				cursor.execute("exec [dbo].[UpsertTG] @TargetGroup=?,@Description=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
# 				cursor.commit()
			
# 		else:
# 			return ("Incorrect header format!!")

# 		if xl_headers_markets == conf_headers_markets:
# 			for ele in get_uniq(file_path, 0, 1, sheet_name = 2):
# 				# print("Inserting Markets.. ", ele[0], ele[1])
# 				cursor.execute("exec [dbo].[UpsertCampaignMarkets] @CampaignMarketName=?,@Description=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
# 				cursor.commit()
				
# 		else:
# 			return ("Incorrect header format!!")
		
# 		empty_rows_dict = {"Location":get_empty_rows(file_path, 1, xl_headers_clients_lead_raw[0]), 
# 		"Clients":get_empty_rows(file_path, 1, xl_headers_clients_lead_raw[1]), 
# 		"Brand":get_empty_rows(file_path, 1, xl_headers_clients_lead_raw[2]),
# 		"Market":get_empty_rows(file_path, 2, xl_headers_markets_raw[0]), "Explanation (Tooltip) markets":get_empty_rows(file_path, 2, xl_headers_markets_raw[1]), 
# 		"Target Group":get_empty_rows(file_path, 0, xl_headers_tg_raw[0]), "Explanation (Tooltip) TG":get_empty_rows(file_path, 0, xl_headers_tg_raw[1])}
		
	
# 		return (jsonify({key:value for key,value in empty_rows_dict.items() if value}))

# 	elif category == 'ChannelGenreMappingSheet':

# 		try:
# 			conf_headers_channel_sheet_raw = get_file_path(conf_file_path)["ChannelMappingSheet"]
# 			conf_headers_channel_sheet = [x.lower().strip() for x in conf_headers_channel_sheet_raw]
# 		except Exception:
# 			return ("Please mention the headers in the conf_path")

# 		try:
# 			onlyfiles = [f for f in listdir(source) if isfile(join(source, f))]
# 		except Exception as e:
# 			print(e)
# 			return ("Folder or file not found in channel sheet mapping")
			
# 		for f in onlyfiles:
# 			try:
# 				shutil.move(source+'\\'+f, dest)
# 			except Exception as e:
# 				#logging.debug(e)
# 				print(e)
# 				return ("Unable to Archive Files!\n Maybe a permission error.")
		
# 		with open(source+'\\'+file_name, 'wb') as fo:
# 			fo.write(base64.b64decode(blob_data.encode('utf-8')))
# 			fo.close()
		
# 		try:
# 			xl_headers_channel_sheet_raw = list(pd.read_excel(source+'\\'+file_name, sheet_name = 0))
# 			xl_headers_channel_sheet = [x.lower().strip() for x in xl_headers_channel_sheet_raw]

# 		except Exception:
# 			return ("Wrong sheet uploaded! \n Please mind the Sheet format: ",conf_headers_channel_sheet_raw)
		
# 		if xl_headers_channel_sheet == conf_headers_channel_sheet:
# 			return ("Files Downloaded!!")
# 		else:
# 			os.remove(source+'\\'+file_name)
# 			return ("Please upload a valid sheet! \n Mind the format: ", conf_headers_channel_sheet_raw)
		
		
# 	else:
# 		return ("Category name is incorrect!")

@app.route('/master_data_settings', methods = ['GET', 'POST'])
def master_data_settings():

	'''
	ui_data = user_id, category, blob_data  

	Location: location_name, user_id
	Client: client_name, location_name, user_id
	Brand :Brand_name, client_name, User_id
	TG: Target_group, User_id
	Campaign_markets: campaign_market_name, user_id
	'''
	ui_data = request.form
	ui_data = ui_data.to_dict()
	# print('ui_dataaaaaa',ui_data)
	data = ast.literal_eval(ui_data['file'])
	file_name = data['filename']
	blob_data = data['blob'].split(',')[1]

	# print('blob_data -> ', blob_data)
	category = data['category']
	print('category -> ', category)
	user_id = data['user_id']

	if category == 'masterdata':

		fp = create_directory(get_file_path(conf_file_path)['MasterDataFilePath'])
		try:
			onlyfiles = [f for f in listdir(source_masterdata) if isfile(join(source_masterdata, f))]
		except Exception as e:
			print(e)
			return ("Folder or file not found in master data setting")
			
		# for f in onlyfiles:
		# 	try: 
		# 		shutil.move(create_directory(get_file_path(conf_file_path)['MasterDataFilePath'])+f, create_directory(get_file_path(conf_file_path)['MasterDataFilePath'])+'\\Archived')
		# 	except Exception as e:
		# 		#logging.debug(e)
		# 		print(e)
		# 		return ("Files does not exists!")
		"""Move file to archive before writing one"""
		move_file(source_masterdata, dest_masterdata, onlyfiles)


		print("sheet downloaded..to -> ", str(source_masterdata + '\\' + file_name))
		file_path = source_masterdata +'\\'+file_name
		with open(file_path,'wb') as f:
			bd = base64.b64decode(blob_data.encode('utf-8'))
			f.write(bd)
			f.close()
		try:

			xl_headers_tg_raw = list(pd.read_excel(file_path, sheet_name = 1))
			xl_headers_tg = [x.lower().strip() for x in xl_headers_tg_raw]
			xl_headers_clients_lead_raw = list(pd.read_excel(file_path, sheet_name = 0))
			xl_headers_clients_lead = [x.lower().strip() for x in xl_headers_clients_lead_raw]
			xl_headers_markets_raw = list(pd.read_excel(file_path, sheet_name = 2))
			xl_headers_markets = [x.lower().strip() for x in xl_headers_markets_raw]
			xl_headers_admin_raw = list(pd.read_excel(file_path, sheet_name = 3))
			xl_headers_admin = [x.lower().strip() for x in xl_headers_admin_raw]

		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the sheet format", xl_headers_tg_raw)

		try:

			conf_headers_clients_lead = get_file_path(conf_file_path)["MasterDataFormatLocationClients"]
			conf_headers_clients_lead = [x.lower().strip() for x in conf_headers_clients_lead]
			conf_headers_tg = get_file_path(conf_file_path)["MasterDataFormatTG"]
			conf_headers_tg = [x.lower().strip() for x in conf_headers_tg]
			conf_headers_markets = get_file_path(conf_file_path)["Markets"]
			conf_headers_markets = [x.lower().strip() for x in conf_headers_markets]
			conf_headers_admin = get_file_path(conf_file_path)["Admins"]
			conf_headers_admin = [x.lower().strip() for x in conf_headers_admin]
			
		except Exception as e:
			print(e)
			return ("Please mention the excel headers in the conf_path file!")
		print(xl_headers_clients_lead, conf_headers_clients_lead )
		if xl_headers_clients_lead == conf_headers_clients_lead:
			wb = xlrd.open_workbook(file_path)
			loc_sheet = wb.sheet_by_index(0)
			location =list(set([loc_sheet.cell_value(i,0) for i in range(1, loc_sheet.nrows)]))
			for ele in location:
				try:
					# print("Inserting Location.. ", ele)
					cursor.execute("exec [dbo].[UpsertLocation] @LocationName=?,@UserId=?",(str(ele).strip(), user_id))
					cursor.commit()
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert Location",os.path.basename(__file__),str(e))

			'''deactivating the entries...'''
			try:
				cursor.execute("exec [dbo].[DeactivateLocations]")
				cursor.commit()
			except Exception as e:
				InsertWebAppException("Python","Deactivate locations",os.path.basename(__file__),str(e))

			for ele in get_uniq(file_path, 0, 1, sheet_name = 0):
				try:
					# print("Inserting Client.. ", ele[0], ele[1])
					cursor.execute("exec [dbo].[UpsertClient] @LocationName=?,@ClientName=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
					cursor.commit()
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert Client",os.path.basename(__file__),str(e))

			'''deactivating the entries...'''
			try:
				cursor.execute("exec [dbo].[DeactivateClient]")
				cursor.commit()
			except Exception as e:
				InsertWebAppException("Python","Deactivate clients",os.path.basename(__file__),str(e))


			for ele in get_uniq(file_path, 1, 2, sheet_name = 0):
				try:
					# print("Inserting Brand.. ", ele[0], ele[1])
					cursor.execute("exec [dbo].[UpsertBrand] @ClientName=?,@BrandName=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
					cursor.commit()
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert Brand",os.path.basename(__file__),str(e))

			'''deactivating the entries...'''
			try:
				cursor.execute("exec [dbo].[DeactivateBrand]")
				cursor.commit()
			except Exception as e:
				InsertWebAppException("Python","Deactivate brands",os.path.basename(__file__),str(e))


			for ele in insert_client_lead(file_path, 0, 1, "Client Leads1", 0):
				try:
					# print("Inserting Client Leads1.. ", ele[0], ele[1], ele[2])
					if ele[2].strip() != '':
						cursor.execute("exec [dbo].[InsertClientLeadFromMasterData] @LocationName=?,@ClientName=?,@UserEmailId=?,@AdminUserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), str(ele[2]).strip(), user_id))
						cursor.commit()
					else:
						pass
				except Exception as e:
					print(e)
					return ("Insertion Error occured!!")

			for ele in insert_client_lead(file_path, 0, 1, "Client Leads2", 0):
				try:
					# print("Inserting Client Leads2.. ", ele[0], ele[1], ele[2])
					if ele[2].strip() != '':
						cursor.execute("exec [dbo].[InsertClientLeadFromMasterData] @LocationName=?,@ClientName=?,@UserEmailId=?,@AdminUserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), str(ele[2]).strip(), user_id))
						cursor.commit()
					else:
						pass
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert Client Leads2",os.path.basename(__file__),str(e))
		else:
			return ("Incorrect header format in Client Leads")
		
		if xl_headers_tg == conf_headers_tg:
			for ele in get_uniq(file_path, 0, 1, sheet_name = 1):
				try:
					# print("Inserting TG.. ", ele[0], ele[1])
					cursor.execute("exec [dbo].[UpsertTG] @TargetGroup=?,@Description=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
					cursor.commit()
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert TG",os.path.basename(__file__),str(e))
			
		else:
			return ("Incorrect header format in TG")

		'''deactivating the entries...'''
		try:
			cursor.execute("exec [dbo].[DeactivateTG]")
			cursor.commit()
		except Exception as e:
			InsertWebAppException("Python","Deactivate TG",os.path.basename(__file__),str(e))


		if xl_headers_markets == conf_headers_markets:
			for ele in get_uniq(file_path, 0, 1, sheet_name = 2):
				try:
					# print("Inserting Markets.. ", ele[0], ele[1])
					cursor.execute("exec [dbo].[UpsertCampaignMarkets] @CampaignMarketName=?,@Description=?,@UserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
					cursor.commit()
				except Exception as e:
					print(Fore.RED+str(e))
					InsertWebAppException("Python","Insert Campaign markets",os.path.basename(__file__),str(e))
				
		else:
			return ("Incorrect header format in Markets")

		'''deactivating the entries...'''
		try:
			cursor.execute("exec [dbo].[DeactivateCampaignMarkets]")
			cursor.commit()
		except Exception as e:
			InsertWebAppException("Python","Deactivate CampaignMarkets",os.path.basename(__file__),str(e))

		if xl_headers_admin == conf_headers_admin:
			try:
				for ele in get_uniq(file_path, 0, 1, sheet_name = 3):
					# print("Inserting Brand.. ", ele[0], ele[1])
					cursor.execute("exec [dbo].[InsertAdminUserFromMasterData] @LocationName=?,@UserEmailId=?,@AdminUserId=?", (str(ele[0]).strip(), str(ele[1]).strip(), user_id))
					cursor.commit()
			except Exception as e:
				print(Fore.RED+str(e))
				InsertWebAppException("Python","Insert Admin",os.path.basename(__file__),str(e))
		else:
			return ("Incorrect header format in Admin")

		empty_rows_dict = {"Location":get_empty_rows(file_path, 0, xl_headers_clients_lead_raw[0]), 
		"Clients":get_empty_rows(file_path, 0, xl_headers_clients_lead_raw[1]), 
		"Brand":get_empty_rows(file_path, 0, xl_headers_clients_lead_raw[2]),
		"Market":get_empty_rows(file_path, 2, xl_headers_markets_raw[0]), "Explanation (Tooltip) markets":get_empty_rows(file_path, 2, xl_headers_markets_raw[1]), 
		"Target Group":get_empty_rows(file_path, 1, xl_headers_tg_raw[0]), "Explanation (Tooltip) TG":get_empty_rows(file_path, 1, xl_headers_tg_raw[1])}
		
	
		return (jsonify({key:value for key,value in empty_rows_dict.items() if value}))

	elif category == 'ChannelGenreMappingSheet':

		fp = create_directory(get_file_path(conf_file_path)['ChannelGenreMappingSheet'])
		try:
			conf_headers_channel_sheet = get_file_path(conf_file_path)["ChannelMappingSheet"]
			conf_headers_channel_sheet = [x.lower().strip() for x in conf_headers_channel_sheet]
		except Exception:
			return ("Please mention the headers in the conf_path")

		try:
			onlyfiles = [f for f in listdir(source_channel) if isfile(join(source_channel, f))]
		except Exception as e:
			print(e)
			return ("Folder or file not found in channel sheet mapping")
			
		"""Move file to Archive before writing one"""
		move_file(source_channel, dest_channel, onlyfiles)
		

		with open(source_channel+'\\'+file_name, 'wb') as fo:
			fo.write(base64.b64decode(blob_data.encode('utf-8')))   
			fo.close()
		
		try:
			xl_headers_channel_sheet_raw = list(pd.read_excel(source_channel+'\\'+file_name, sheet_name = 0))
			xl_headers_channel_sheet = [x.lower().strip() for x in xl_headers_channel_sheet_raw]

		except Exception:
			return ("Wrong sheet uploaded! \n Please mind the Sheet format: ",xl_headers_channel_sheet_raw)

		
		if xl_headers_channel_sheet == conf_headers_channel_sheet:
			return ("Files Downloaded!!")
		else:
			os.remove(source_channel+'\\'+file_name)
			return ("Please upload a valid sheet! \n Mind the format: ")
		

	else:
		return ("Category name is incorrect")


@app.route('/get_file_names', methods = ["GET", "POST"])    
# def get_file_names():   #santosh code
#     """
#     Expects From UI: PlanId
#     """
#     ui_data = request.form
#     # ui_data = ui_data.to_dict()
#     print(ui_data)
#     ui_data = ui_data.to_dict()
#     ui_data = ast.literal_eval(ui_data['file'])
#     PlanId = ui_data["plan_id"]
#     cursor.execute("exec [dbo].[GetFilePathsForPlan] @PlanId=?",(PlanId))
#     result = cursor.fetchall()
#     print(result)
#     file_dict = {}
#     try:
#         for i in range(len(result)):
#             for ele in result[i]:
#                 if ele:
#                     file_dict[ele.split("\\")[-1]] = ele
#                 else:
#                     pass 
#     except Exception as e:
#         # logging.debug(e)
#         return ('No data for PlanId sent',e)
#     print('file_dict', file_dict)
#     return jsonify(file_dict)


def get_file_names():     #writen by harnath
	"""
	Expects From UI: PlanId
	"""
	ui_data = request.form
	# ui_data = ui_data.to_dict()
	print(ui_data)
	results=[]
	ui_data = ui_data.to_dict()
	ui_data = ast.literal_eval(ui_data['file'])
	PlanId = ui_data["plan_id"]
	cursor.execute("exec [dbo].[GetFilePathsForPlan] @PlanId=?",(PlanId))
	columns = [column[0] for column in cursor.description]
	print(Fore.WHITE+"file columns names are :",columns)
	for row in cursor.fetchall():
		results.append(dict(zip(columns, row)))
	try:
		file_dic={}
		keys=results[0].keys()
		for key in keys:
			if (results[0][key]):
				#print('---------------------------------------------')
				#print(results[0][key])
				results[0][key]=results[0][key].replace('/','\\')
				file_name=results[0][key].split("\\")[-1]
				file_dic[file_name]=results[0][key]
				#print(results[0][key].split("\\")[-1])
				#print('----------------------------------------------')
			else :
				pass
		print(Fore.WHITE+"file name and file path are :",file_dic)
		return (file_dic)
	except Exception as e:
		print(e)
		print(Fore.RED+"error in get_file_names function")
		print(Fore.RED+str(e))
		InsertWebAppException("Python","get_file_names function",os.path.basename(__file__),str(e))



@app.route('/download_file', methods = ["GET", "POST"]) 
# def download_file_1():
# 	"""
# 	Expects From UI: abs_path   <type: list>   #"C:\\Banglore\\Google\\120719141405\\1\\aditi_patil\\Closed Account Cases.xlsx"
# 	"""
# 	abs_path = request.form
# 	abs_path = abs_path.to_dict()
# 	abs_path = ast.literal_eval(abs_path['file'])
# 	file_paths = abs_path["file_path"]
# 	print('inside download file function of route call')
# 	print('files path is',file_paths)
# 	with ZipFile("WMDemo.zip", 'w') as zi:
# 		for file in file_paths: 
# 			zi.write(file)
# 		zi.close()
# 	with open("WMDemo.zip", 'rb') as fo:
# 		blob = base64.b64encode(fo.read())
# 		fo.close()
# 	return (blob)

# def download_file_1():   # by harnath
# 	"""
# 	Expects From UI: abs_path   <type: list>   #"C:\\Banglore\\Google\\120719141405\\1\\aditi_patil\\Closed Account Cases.xlsx"
# 	"""
# 	abs_path = request.form
# 	abs_path = abs_path.to_dict()
# 	abs_path = ast.literal_eval(abs_path['file'])
# 	print('paths for download are',abs_path)
# 	file_paths = abs_path["file_path"]
# 	if len(file_paths)>1:
# 		print('will send a zip')
# 		with ZipFile("WMDemo.zip", 'w') as zi:
# 			for file in file_paths: 
# 				zi.write(file)
# 			zi.close()
# 		with open("WMDemo.zip", 'rb') as fo:
# 			blob = base64.b64encode(fo.read())
# 			fo.close()
# 		return (blob)
# 	else:
# 		print("will send a single file ")
# 		#with open(file_paths[0].split('\\')[-1], 'rb') as fo:
# 		with open(file_paths[0], 'rb') as fo:		
# 			blob = base64.b64encode(fo.read())
# 			fo.close()
# 		return (blob)

def download_file_1(): #harnath
	"""
	Expects From UI: abs_path   <type: list>   #"C:\\Banglore\\Google\\120719141405\\1\\aditi_patil\\Closed Account Cases.xlsx"
	"""
	abs_path = request.form
	abs_path = abs_path.to_dict()
	abs_path = ast.literal_eval(abs_path['file'])
	print(Fore.GREEN+'paths for download are',abs_path)
	file_paths = abs_path["file_path"]
	if len(file_paths)>1:
		print(Fore.WHITE+'blob data with out structure multiple files ')

		listOfFiles = getListOfFiles(str(get_file_path["Tempmultiplefilefolder"])+'\\')       #'C:\\temp_multiple_file\\'
		print(Fore.WHITE+'files list is :')
		print(listOfFiles)
		if listOfFiles:
			for i in listOfFiles:
				os.remove(i)
			print('old files deleted')
		
		for filepath in file_paths:
			print()
			print(Fore.WHITE+"file about to move is")
			print(filepath)

			#src='C:\\Users\\AlgonoX\\Desktop\\folder_1\\me.xlsx'
			#dst='C:\\Users\\AlgonoX\\Desktop\\folder2'
			#shutil.copyfile(src, dst)

			src=filepath
			dst=str(get_file_path["Tempmultiplefilefolder"])                      #'C:\\temp_multiple_file'
			shutil.copy2(src,dst)
			print(Fore.WHITE+'file copy done ')

		print(Fore.WHITE+'moved multiple files ')

		listOfFiles = getListOfFiles(str(get_file_path["Tempzipfolder"]+'\\'))                           #'C:\\temp_zip\\'
		#print(Fore.WHITE+'files list is :')
		#print(listOfFiles)
		if (listOfFiles):
			for i in listOfFiles:
				os.remove(i)
			print('old files deleted')
		

		output_filename=str(get_file_path["Tempzipmultiplefilefolder"])       #'C:\\temp_zip\\multiple_files' #path with file name also
		dir_name=str(get_file_path["Tempmultiplefilefolder"])                        #'C:\\temp_multiple_file'
		print(output_filename)
		shutil.make_archive(output_filename, 'zip', dir_name)
		print()
		print(Fore.WHITE+'folder ---> zip done')
		print(Fore.WHITE+'zip ---> blog start')
		with open(output_filename+str('.zip'), 'rb') as fo:   #path with file name plus zip
			blob = base64.b64encode(fo.read())
			fo.close()
		print(Fore.WHITE+'zip ---> blog done')
		return (blob)

	else:
		print(Fore.WHITE+'blob data for only single file with out structure')
		#file_list=glob.glob("P:\\temp_single_file\\")
		#print(glob.glob("/home/adam/*.txt"))
		#print()
		listOfFiles = getListOfFiles(get_file_path["Tempsinglefile"])                               #'C:\\temp_single_file\\'
		print(Fore.WHITE+'files list is :')
		print(listOfFiles)
		return_dic={}
		if listOfFiles:
			for i in listOfFiles:
				os.remove(i)
			print('old files deleted')
		
		print(Fore.WHITE+"file about to move is")
		print(file_paths[0])

		#src='C:\\Users\\AlgonoX\\Desktop\\folder_1\\me.xlsx'
		#dst='C:\\Users\\AlgonoX\\Desktop\\folder2'
		#shutil.copyfile(src, dst)

		src=file_paths[0]
		file_name_only=str(file_paths[0].split('\\')[-1])
		print()
		print('only file name is :',file_name_only)
		file_name_extenction=str(file_paths[0].split('.')[-1])
		print()
		print('file extenction name is :',file_name_extenction)

		print('file ---> copy file start')
		dst='C:\\temp_single_file'
		shutil.copy2(src,dst)
		print('file ---> copy file done ')
		print('file ---> blob start')

		data = open(get_file_path["Tempsinglefile"]+str(file_name_only), "rb").read()          #'C:\\temp_single_file\\'
		blob = base64.b64encode(data)
		#print (data)
		
		print()
		#print(blob)
		print('file ---> blob done')
		#return_dic['blob']=blob
		#return_dic['filename']=file_name_only
		return blob


@app.route('/download_all_files', methods = ["GET", "POST"])
def download_all_files():
	abs_path = request.form
	abs_path = abs_path.to_dict()
	abs_path = ast.literal_eval(abs_path['file'])
	print('paths for download are',abs_path)
	file_paths = abs_path["file_path"]
	if file_paths[0]:
		listOfFiles = getListOfFiles(str(path_dic["Tempzipfolder"])+'\\')           #getListOfFiles('C:\\temp_zip\\')
		print(Fore.WHITE+'files list is :')
		print(listOfFiles)
		if listOfFiles:
			for i in listOfFiles:
				os.remove(i)
			print('old files deleted')

		print('----------------------inside if-----------------------------')
		s=file_paths[0].split('\\')
		s=s[:7]
		print(s)
		#output_filename_1='C:\\Users\\indtvautop1\\Desktop\\python files to run\\temp_zip'
		#output_filename='C:\\Users\\indtvautop1\\Desktop\\python files to run\\temp_zip\\'+str(s[-1])
		output_filename_1=path_dic["Tempzipfolder"]                                    #'C:\\temp_zip'
		output_filename=str(path_dic["Tempzipfolder"])+'\\'+str(s[-1])                 #'C:\\temp_zip\\'+str(s[-1]) #path with file name also

		dir_name=str("\\".join(s))
		print(output_filename)
		shutil.make_archive(output_filename, 'zip', dir_name)
		with open(output_filename+str('.zip'), 'rb') as fo:   #path with file name plus zip
			blob = base64.b64encode(fo.read())
			fo.close()
		return (blob)


"""=================================================================santosh End========================================================"""

if __name__ == "__main__":
	#app.run()
	#SQL_Connect()
	# context = ('C:\\wildcard_wmglobal_com_1540228401735\\STAR_wmglobal_com.crt','C:\\wildcard_wmglobal_com_1540228401735\\STAR_wmglobal_com.key')
	# app.run(host="0.0.0.0", port=6767, debug=True, threaded=True, ssl_context=context)
	app.run(host="0.0.0.0", port=6767, debug=True, threaded=True)
	
